import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;

public class SwingAppDollar {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingAppDollar window = new SwingAppDollar();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SwingAppDollar() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(49, 54, 130, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("New label");
		JLabel lblDollar = new JLabel("Dollar");
		lblDollar.setBounds(49, 30, 61, 16);
		frame.getContentPane().add(lblDollar);
		
		JButton btnOk = new JButton("Ok");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double d = Double.parseDouble(textField.getText());
				double s = d*4.3;
				lblNewLabel.setText(textField.getText()+" dollar = "+String.valueOf(s));
				
				
				
			}
		});
		btnOk.setBounds(49, 86, 117, 29);
		frame.getContentPane().add(btnOk);
		
		
		textField.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyReleased(KeyEvent arg0) {
				// TODO Auto-generated method stub
				try {
					
					if (textField.getText().equals(""))
						lblNewLabel.setText("0 dollar 0 TL");
					
					double d = Double.parseDouble(textField.getText());
					double s = d*4.3;
					lblNewLabel.setText(textField.getText()+" dollar = "+String.valueOf(s) +" TL");
				
				}
				catch(Exception e) {
					
				}
				
				
			}
			
			@Override
			public void keyPressed(KeyEvent arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		
		
		lblNewLabel.setBounds(49, 149, 164, 16);
		frame.getContentPane().add(lblNewLabel);
	}

}
