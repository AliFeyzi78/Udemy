package dbPack;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class dpApp1 {

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub

		
		
		Class.forName("org.postgresql.Driver");
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/database2","postgres","12341234");
			
			
		
			
			
			System.out.println("connected");
			
//			PreparedStatement ps = conn.prepareStatement("select * from table1" );
//			ResultSet rs = ps.executeQuery();
			
//			while (rs.next()) {
//				System.out.println(rs.getString(1));
//				System.out.println(rs.getString(2));
//				System.out.println(rs.getString(3));
//			}
			
			
//			String updatesql = "update table1 set age=57 where name='furkan'";
//			String deletesql = "delete from table1 where id>1018";
//			String insertsql = "insert into table1 (name,surname) values ('özgen','imrag')";

			
			
//			
//			Statement st = conn.createStatement();
//			st.execute(insertsql);
			
			CallableStatement cs = conn.prepareCall("{call insertData(?,?)}");
			cs.setString(1, "hakancan");
			cs.setInt(2, 30);
			cs.execute();
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}



















