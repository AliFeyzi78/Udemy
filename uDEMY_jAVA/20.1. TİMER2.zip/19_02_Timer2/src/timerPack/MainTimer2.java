package timerPack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JSpinner;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.event.ActionEvent;

public class MainTimer2 {

	private JFrame frame;
	private static Timer timer;
	private int sayac;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainTimer2 window = new MainTimer2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public MainTimer2() {
		initialize();
	}


	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("0");
		JSpinner spinner = new JSpinner();
		spinner.setBounds(181, 87, 73, 26);
		frame.getContentPane().add(spinner);
		
		JButton btnBaslat = new JButton("Baslat");
		btnBaslat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				timer=new Timer();
				sayac=Integer.valueOf(String.valueOf(spinner.getValue()));
				label.setText(String.valueOf(sayac));
				
				if(sayac==0) return;
				TimerTask timerTask = new TimerTask() {
					
					@Override
					public void run() {
						sayac--;
						label.setText(String.valueOf(sayac));
						if(sayac==0)timer.cancel();
					}
				};
				
				timer.schedule(timerTask, 1000,1000);
				
			}
		});
		btnBaslat.setBounds(27, 145, 117, 29);
		frame.getContentPane().add(btnBaslat);
		
		JButton btnDuraklat = new JButton("Duraklat");
		btnDuraklat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				timer.cancel();
				spinner.setValue(sayac);
			}
		});
		btnDuraklat.setBounds(156, 145, 117, 29);
		frame.getContentPane().add(btnDuraklat);
		
		JButton btnDurdur = new JButton("Durdur");
		btnDurdur.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				timer.cancel();
				spinner.setValue(0);
			}
		});
		btnDurdur.setBounds(279, 145, 117, 29);
		frame.getContentPane().add(btnDurdur);
		
		
		label.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		label.setBounds(193, 208, 80, 26);
		frame.getContentPane().add(label);
	}

}
