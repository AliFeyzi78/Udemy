package awt1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class AwtClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Frame f = new Frame();
		f.setSize(300, 200);
		f.setVisible(true);
		f.setLayout(new FlowLayout());
		
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});
		
		Button btn1 = new Button("Print");
		TextField tf1 = new TextField();
		f.add(btn1);
//		btn1.setBounds(50, 50, 100, 30);
		
		btn1.setSize(100, 30);
		btn1.setLocation(50, 30);
		btn1.setLabel("Button1");
		
		btn1.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				System.out.println(tf1.getText());
				
			}
			
		});
		
		
		f.add(tf1);
		tf1.setBounds(50, 100, 100, 25);
		
		tf1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				System.out.println(tf1.getText());
			}
		});
		
		
		tf1.addTextListener(new TextListener() {
			
			@Override
			public void textValueChanged(TextEvent arg0) {
				// TODO Auto-generated method stub
				System.out.println(tf1.getText());
			}
		});
		
//		TextArea ta1 = new TextArea();
//		ta1.setBounds(50, 100, 100, 60);
//		f.add(ta1);
//		
//		ta1.addTextListener(new TextListener() {
//			
//			@Override
//			public void textValueChanged(TextEvent arg0) {
//				// TODO Auto-generated method stub
//				System.out.println(ta1.getText());
//			}
//		});
		
	}

}
