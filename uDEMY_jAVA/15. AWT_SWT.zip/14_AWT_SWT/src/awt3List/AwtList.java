package awt3List;

import java.awt.*;


public class AwtList {

//	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Frame f = new Frame();
		f.setVisible(true);
		f.setSize(300, 400);
		f.setLayout(new FlowLayout());
		
		List list = new List();
		list.setSize(150, 300);
		list.setLocation(20, 20);
		f.add(list);
		
		list.add("Java");
		list.add("AWT");
		list.add("GUI", 1);
		
//		list.remove(0);
		
		System.out.println(list.getItem(2));
		
	
		
	}

}
