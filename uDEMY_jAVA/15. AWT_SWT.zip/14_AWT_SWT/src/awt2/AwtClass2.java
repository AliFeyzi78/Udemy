package awt2;

import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;


public class AwtClass2 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Frame f = new Frame();
		f.setSize(200, 150);
		f.setLayout(new FlowLayout());
		f.setVisible(true);
		
		Label lbl1 = new Label("text");
		lbl1.setLocation(20, 30);
		lbl1.setSize(150, 25);
		f.add(lbl1);
		lbl1.setText("Java");
		lbl1.setName("lbl1");
		System.out.println(lbl1.getName());
		lbl1.setAlignment(Label.LEFT);
		
		Checkbox cb = new Checkbox("select status");
		cb.setLocation(20, 60);
		cb.setSize(150,30);
		f.add(cb);
		
		cb.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				
				
//				if(cb.getState()) lbl1.setText("active");
//				else lbl1.setText("not active");
				
				lbl1.setText(e.getStateChange()==1?"active":"not active");
			}
		});
		
		
	}

}
