package passApp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SwingPass {

	private JFrame frame;
	private JTextField txt1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingPass window = new SwingPass();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SwingPass() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		txt1 = new JTextField();
		txt1.setBounds(40, 42, 130, 26);
		frame.getContentPane().add(txt1);
		txt1.setColumns(10);
		
		JLabel label1 = new JLabel("New label");
		JButton button1 = new JButton("New button");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				StringBuilder sb = new StringBuilder(txt1.getText());
				for(int i=0; i<sb.length(); i++) {
					sb.setCharAt(i, (char)(sb.charAt(i)+2));
				}
				
				label1.setText(sb.toString());
			}
		});
		button1.setBounds(40, 78, 117, 29);
		frame.getContentPane().add(button1);
		
		
		label1.setBounds(50, 119, 151, 26);
		frame.getContentPane().add(label1);
		
		
		
		
	}

}


//ab12
//cd34



