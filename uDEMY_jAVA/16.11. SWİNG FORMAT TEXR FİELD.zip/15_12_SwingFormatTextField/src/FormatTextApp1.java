import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.NumberFormat;
import java.text.ParseException;

import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.text.MaskFormatter;

public class FormatTextApp1 {

	private JFrame frame;
	JFormattedTextField text1, text2;
	MaskFormatter format1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FormatTextApp1 window = new FormatTextApp1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FormatTextApp1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		
		
		
		NumberFormat moneyFormat = NumberFormat.getCurrencyInstance();
		
		text1 = new JFormattedTextField(moneyFormat);
		text1.setBounds(50, 50, 120, 40);
		frame.getContentPane().add(text1);
		text1.setValue(1000);
		text1.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				try
				{
					text1.setValue(new Integer(Integer.parseInt(text1.getText())));
				}
				catch(Exception ex) {}
			}
		});
		
		
		try {
			format1 = new MaskFormatter("0### ### ## ##");
			
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		text2 = new JFormattedTextField(format1);
		text2.setBounds(50, 100, 120, 40);
		frame.getContentPane().add(text2);
		
		
				
		
		
		
	}

}
