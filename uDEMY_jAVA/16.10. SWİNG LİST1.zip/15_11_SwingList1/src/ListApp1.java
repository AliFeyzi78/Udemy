import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.AbstractListModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.JLabel;

public class ListApp1 {
	


	private JFrame frame;
	private JTextField txt1;
	private JLabel labelList;
	
	
	String mytext="";


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListApp1 window = new ListApp1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ListApp1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 562, 470);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		txt1 = new JTextField();
		txt1.setBounds(53, 50, 130, 26);
		frame.getContentPane().add(txt1);
		txt1.setColumns(10);
		
		DefaultListModel<String> dlist1 = new DefaultListModel();
		JButton btnAdd = new JButton("New button");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String str = txt1.getText();
				dlist1.addElement(str);
//				dlist1.add(1, str);
			}
		});
		btnAdd.setBounds(53, 88, 117, 29);
		frame.getContentPane().add(btnAdd);
		
		
		dlist1.addElement("beşiktaş");
		dlist1.addElement("galatasaray");
		dlist1.addElement("fenerbahçe");
		dlist1.addElement("trabzonspor");
		dlist1.addElement("erzurumspor");
		
		
		
		JList list1 = new JList(dlist1);
		
		list1.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				
				mytext="<html>";
				
				for (int i=0; i<list1.getSelectedValues().length; i++) {
					mytext+=list1.getSelectedValues()[i] +"<br>";
					labelList.setText(mytext);
				}
				
				
				
			}
		});
		
		
		
		list1.setBounds(53, 142, 130, 152);
		frame.getContentPane().add(list1);
		
		labelList = new JLabel("New label");
		labelList.setBounds(55, 317, 213, 113);
		frame.getContentPane().add(labelList);
		
		
	}
}
