package labelApp;

import java.awt.EventQueue;

import javax.swing.ButtonModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SwingLabelApp {

	private JFrame frame;
	private JTextField txt1;
	private JTextField txt2;
	private JLabel label3;
	private JTextField txt3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingLabelApp window = new SwingLabelApp();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SwingLabelApp() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label1 = new JLabel("New label");
		label1.setBounds(48, 36, 167, 26);
		frame.getContentPane().add(label1);
		
		txt1 = new JTextField();
		txt1.setBounds(48, 74, 130, 26);
		frame.getContentPane().add(txt1);
		txt1.setColumns(10);
		
		JLabel label2 = new JLabel("New label");
		label2.setBounds(48, 123, 61, 16);
		frame.getContentPane().add(label2);
		
		txt2 = new JTextField();
		txt2.setBounds(48, 151, 130, 26);
		frame.getContentPane().add(txt2);
		txt2.setColumns(10);
		
		label3 = new JLabel("New label");
		label3.setBounds(48, 207, 61, 16);
		frame.getContentPane().add(label3);
		
		txt3 = new JTextField();
		txt3.setBounds(48, 236, 130, 26);
		frame.getContentPane().add(txt3);
		txt3.setColumns(10);
		
		
		label1.setDisplayedMnemonic('a');
		label2.setDisplayedMnemonic('b');
		label3.setDisplayedMnemonic('c');
		
		label1.setLabelFor(txt1);
		label2.setLabelFor(txt2);
		label3.setLabelFor(txt3);
		
		ImageIcon img = new ImageIcon("micon.png");
		label1.setIcon(img);
		
		
		
		
	}
}
