package degerDondurme;

public class degerDondurenMetot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(topla(4,7));
		System.out.println(asal(17));
		
		
	}
	
	
	public static int topla(int a, int b)
	{
		return a+b;
	}
	
	public static Boolean asal(int sayi)
	{
		Boolean durum=true;
		for (int i=2;i<sayi;i++)
		{
			if (sayi % i ==0)
			{
				durum=false;
				break;
				
			}
		}
		
		return durum;
		
	}
	
	
	
	
	

}
