package overloadMetot;

public class overloadMetot1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Overload 
		
		topla(4,6);
		topla("Test","String");
		topla (4,6,7);
		
	}
	
	public static void topla(int a, int b)
	{
		System.out.println(a+b);
	}
	
	public static void topla(String a, String b)
	{
		System.out.println(a+b);
	}
	
	
	public static void topla(int a,int b, int c)
	{
		System.out.println(a+b+c);
	}
	
	

}
