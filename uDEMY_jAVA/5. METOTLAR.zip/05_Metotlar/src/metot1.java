
public class metot1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		isimYazdir("Özgen İMRAĞ",27);
		isimYazdir("Gökhan ARSLAN",28);
		
		topla(30,8);
		
		
	}
	
	public static void yazdir() {
		System.out.println("Gökhan ARSLAN");
		
	}
	
	
	public static void isimYazdir(String isim, int yas)
	{
		System.out.println(isim+" "+yas);
	}
	
	public static void topla(int a, int b)
	{
		System.out.println(a+b);
	}
	
	
		

}
