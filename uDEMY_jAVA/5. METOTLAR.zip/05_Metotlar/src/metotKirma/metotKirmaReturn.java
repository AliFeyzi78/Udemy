package metotKirma;

public class metotKirmaReturn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		metotKirma(15);
		
		
		
		
		
	}
	
	
	
	public static void metotKirma(int sayi)
	{
		for(int i=0;i<=sayi;i++)
		{
			System.out.println(i);
			if (i==7) return;
		}
		
		System.out.println("finish");
	}

}
