package recursiveMetot;

public class recursiveMetot1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for (int i=2; i<11; i++)
		{
			System.out.println(fibonacci(i));
		}

	}
	
	static int fibonacci(int n)
	{
		if (n<2)
			return n;
		else
			return fibonacci(n-1) + fibonacci(n-2);
	}

}
