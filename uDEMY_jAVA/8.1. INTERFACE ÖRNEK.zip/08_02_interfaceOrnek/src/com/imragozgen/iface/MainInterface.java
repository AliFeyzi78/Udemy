package com.imragozgen.iface;

public class MainInterface {

	public static void main(String[] args) {
		
		Hesapla hesapla = new Hesapla(5,7);

		System.out.println("çevre : "+ hesapla.hesapla());
	}

}
