package com.imragozgen.iface;

public interface Dikdortgen {
	public int kisaKenar();
	public void setKisaKenar(int kisaKenar);
	
	public int uzunKenar();
	public void setUzunKenar(int uzunKenar);
}
