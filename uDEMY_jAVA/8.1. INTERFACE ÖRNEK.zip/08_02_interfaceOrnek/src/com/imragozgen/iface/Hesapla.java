package com.imragozgen.iface;

public class Hesapla implements Dikdortgen {
	private int kisaKenar,uzunKenar;
	
	public Hesapla(int kkenar,int ukenar) {
		this.kisaKenar=kkenar;
		this.uzunKenar=ukenar;
	}

	@Override
	public int kisaKenar() {
		
		return this.kisaKenar;
	}

	@Override
	public void setKisaKenar(int kisaKenar) {
		this.kisaKenar=kisaKenar;
		
	}

	@Override
	public int uzunKenar() {
	
		return this.uzunKenar;
	}

	@Override
	public void setUzunKenar(int uzunKenar) {
		this.uzunKenar=uzunKenar;
		
	}
	
	public int hesapla() {
		return 2*(uzunKenar+kisaKenar);
	}
	
}
