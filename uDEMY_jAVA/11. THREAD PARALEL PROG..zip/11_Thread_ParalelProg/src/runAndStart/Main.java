package runAndStart;

public class Main {

	public static void main(String[] args) {
		//Thread
		//Runnable
		
		Kanal1 k1 = new Kanal1();
		Kanal2 k2 = new Kanal2();

//		k1.start();
//		k2.start();
		
		Kanal3 k3 = new Kanal3();
		Kanal4 k4 = new Kanal4();
//		k3.run();
//		k4.run();
		
		
		
		Thread t5 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println("çalıştı");
				
			}
		});
		
		t5.start();
		
		
		Runnable r5 = new Runnable() {
			
			@Override
			public void run() {
				Kanal1 kk1 = new Kanal1();
				kk1.start();
				
			}
		};
		r5.run();
		
		
	}

}

class Kanal1 extends Thread{
	public void run() {
		for(int i=0;i<10;i++)
			System.out.println("kanal 1 :"+i);
	}
}

class Kanal2 extends Thread{
	public void run() {
		for(int i=0;i<10;i++)
			System.out.println("kanal 2 :"+i);
	}
}

class Kanal3 implements Runnable{
	public void run() {
		for(int i=0;i<10;i++)
			System.out.println("kanal 3 :"+i);
	}
}

class Kanal4 implements Runnable{
	public void run() {
		for(int i=0;i<10;i++)
			System.out.println("kanal 4 :"+i);
	}
}