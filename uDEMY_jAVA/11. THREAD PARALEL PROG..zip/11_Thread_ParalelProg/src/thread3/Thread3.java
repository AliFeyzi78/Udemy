package thread3;

public class Thread3 {

	public static void main(String[] args){
		// TODO Auto-generated method stub

		Thread thread1 = new Thread(new Channel2());
		thread1.start();
		
		System.out.println("start ->" +	thread1.isAlive());
		try {
			thread1.join();
		}
		catch(Exception e) {}
		
		
		System.out.println("finish -> "+ thread1.isAlive());
	}

}



class Channel2 extends Thread
{
	Thread th;
	
	Channel2(){
		th = new Thread(this,"channel 2");
		
	}
	
	public void run() {
		
		try
		{
			for (int i=0; i<=3; i++) {
				System.out.println(i);
				Thread.sleep(500);
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
}


