package thread2;

public class NewChannel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new Channel2();
		

		
		try
		{
			for (int i=0; i<=5; i++)
			{
				System.out.println("Main Channel -> "+ i);
				Thread.sleep(1000);
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		
	}

}


class Channel2 implements Runnable
{
	
	Thread th2;
	
	Channel2(){
		th2 = new Thread(this, "Channel 2");
//		System.out.println(th2.getName());
		
		th2.start();
	}
	
	public void run()
	{
		try
		{
			for (int i=0; i<=5; i++)
			{
				System.out.println("channel 2 -> "+ i);
				th2.sleep(1000);
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		
	}
	
}