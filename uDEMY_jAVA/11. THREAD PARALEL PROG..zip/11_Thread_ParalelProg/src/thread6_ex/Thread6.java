package thread6_ex;

public class Thread6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Fabrika f = new Fabrika();
		f.stok=0;
		Kanal1 k1 = new Kanal1(f);
		Kanal2 k2= new Kanal2(f);
		k1.start();
		k2.start();

	}

}

class Fabrika
{
	int stok;
	boolean stokDurum=true;
	
	synchronized void uret() {
		
		while(!stokDurum) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		stok++;
		System.out.println("+ "+stok);
		stokDurum=false;
		notify();
	}
	
	synchronized void tuket() {
		
		while(stokDurum) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		stok--;
		System.out.println("- "+stok);
		stokDurum=true;
		notify();
	}
}

class Kanal1 extends Thread{
	Fabrika f;
	public Kanal1(Fabrika f) {
		this.f=f;
	}
	
	public void run() {
		for (int i =0; i<10; i++) {
			f.uret();
		}
	}
}


class Kanal2 extends Thread{
	Fabrika f;
	public Kanal2(Fabrika f) {
		this.f=f;
	}
	
	public void run() {
		for (int i=0; i<10; i++) {
			f.tuket();
		}
	}
}