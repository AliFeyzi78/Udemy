package thread4;

public class Thread4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Thread t2 = new Thread(new MyThread2());
		Thread t3 = new Thread(new MyThread3());
		Thread t4 = new Thread(new MyThread4());
		
		t4.setPriority(Thread.MAX_PRIORITY);
		t2.setPriority(Thread.NORM_PRIORITY);
		t3.setPriority(Thread.MIN_PRIORITY);
		
		t4.start();
		t2.start();
		t3.start();
		
	}

}


class MyThread2 extends Thread
{
	Thread th;
	
	MyThread2(){
		th = new Thread(this,"channel 2");
		
	}
	
	public void run() {
		try {
			for (int i = 0; i<=20; i++) {
				System.out.println("ch2   ->   "+ i);
			}
		}
		catch(Exception e) {System.out.println(e);}
	}
}

class MyThread3 extends Thread
{
	Thread th;
	
	MyThread3(){
		th = new Thread(this,"channel 3");
		
	}
	
	public void run() {
		try {
			for (int i = 0; i<=20; i++) {
				System.out.println("ch3   ->   "+ i);
			}
		}
		catch(Exception e) {System.out.println(e);}
	}
}

class MyThread4 extends Thread
{
	Thread th;
	
	MyThread4(){
		th = new Thread(this,"channel 4");
		
	}
	
	public void run() {
		try {
			for (int i = 0; i<=20; i++) {
				System.out.println("ch4   ->   "+ i);
			}
		}
		catch(Exception e) {System.out.println(e);}
	}
}