package thread5_senk;

public class Thread5 {
	
	int z=0;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Thread5 obj1 = new Thread5();
		obj1.mt1();

		
		System.out.println("z="+obj1.z);
	}
	
	
	
	public void mt1() {
		
		Thread t1 = new Thread(new Runnable() {
			public void run() {
				plus();
			}
		});
		
		Thread t2 = new Thread(new Runnable() {
			public void run() {
				minus();
			}
		});
		
		t1.start();
		t2.start();
		
		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public synchronized void plus() {
		for (int i=0; i<50; i++)
		{
			z++;
			
			System.out.println("+ "+z);
		}
	}
	
	public synchronized void minus() {
		for (int i=0; i<50; i++) {
			z--;
			System.out.println("- "+z);
		}
	}
}


