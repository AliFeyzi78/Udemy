package Thread1;

public class MainChannel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Thread th1 = Thread.currentThread();
		th1.setName("Main Channel");
		System.out.println(th1.getName());
		
		try
		{
			for (int i=0;i<=5;i++)
			{
				System.out.println(i);
				Thread.sleep(2000);
			}
		}
		catch(Exception e) {
			System.out.println("main channel error");
		}
		
	}
}
	


