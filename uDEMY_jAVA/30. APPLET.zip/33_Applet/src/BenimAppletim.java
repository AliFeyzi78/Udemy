import java.awt.Graphics;

import javax.swing.JApplet;

public class BenimAppletim extends JApplet {
	
	public void init() {
		System.out.println("applet başladı.");
	}
	
	public void stop() {
		System.out.println("applet durdu.");
	}
	
	public void paint(Graphics g) {
		g.drawString("JAVA APPLET", 20, 30);
	}

}
