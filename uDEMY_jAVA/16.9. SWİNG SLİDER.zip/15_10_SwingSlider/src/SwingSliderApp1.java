import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Hashtable;
import java.awt.event.ActionEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JProgressBar;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.ListModel;

public class SwingSliderApp1 {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingSliderApp1 window = new SwingSliderApp1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SwingSliderApp1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel labelValue = new JLabel("New label");
		
		
		
		JSlider slider = new JSlider();
		slider.setMaximum(10);
		slider.setMinimum(-10);
		slider.setSnapToTicks(true);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.setValue(0);
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				labelValue.setText(String.valueOf(slider.getValue()));
			}
		});
		
		Hashtable<Integer, JLabel> table = new Hashtable<Integer, JLabel>();
		table.put(-10, new JLabel("Left"));
		table.put(0, new JLabel("Center"));
		table.put(10, new JLabel("Right"));
		slider.setLabelTable(table);
		slider.setValue(30);
		slider.setBounds(51, 104, 142, 61);
		frame.getContentPane().add(slider);
		
		JProgressBar progressBar = new JProgressBar();
		JButton button1 = new JButton("New button");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				progressBar.setValue(70);
			}
		});
		button1.setBounds(59, 173, 117, 29);
		frame.getContentPane().add(button1);
		
		
		labelValue.setBounds(79, 222, 99, 16);
		frame.getContentPane().add(labelValue);
		
		
		progressBar.setValue(40);
		progressBar.setBounds(62, 29, 116, 51);
		frame.getContentPane().add(progressBar);
		
		
		progressBar.setString("java");
		progressBar.setStringPainted(true);
		
	}
}
