package lambdaInterfaceOrnek;

public class Main {

	public static void main(String[] args) {
		Selamla s1 = isim -> System.out.println("Merhaba "+ isim);
		s1.selam("Özgen");
		
		Selamla s2 = new Selamla() {
			
			@Override
			public void selam(String s) {
				System.out.println("Merhaba "+s);
				
			}
		};
		s2.selam("Ahmet");

	}

}

interface Selamla{
	public void selam(String s);
}
