package predicateArayuzu2copy;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class Main {

	public static void main(String[] args) {
		
		
		
		Ogrenciler ogr1 = new Ogrenciler("Ahmet", "erkek", 45);
		Ogrenciler ogr2 = new Ogrenciler("Mehmet", "erkek", 55);
		Ogrenciler ogr3 = new Ogrenciler("Ayşe", "kız", 65);
		Ogrenciler ogr4 = new Ogrenciler("Mustafa", "erkek", 40);
		Ogrenciler ogr5 = new Ogrenciler("Fatma", "kız", 45);
		Ogrenciler ogr6 = new Ogrenciler("Furkan", "erkek", 90);
		
		List<Ogrenciler> liste = new ArrayList<Ogrenciler>();
		liste.add(ogr1);
		liste.add(ogr2);
		liste.add(ogr3);
		liste.add(ogr4);
		liste.add(ogr5);
		liste.add(ogr6);
		
		
		liste.stream().filter(getir()).forEach(a->System.out.println(a.getOgrenciAdi()));
		
	
		
	}
	
	public static Predicate<Ogrenciler> getir(){
		return p->p.getNot()>50 && p.getCinsiyet().equals("kız");
	}
	
	
}

