package mapvereduce;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {
		List<Arabalar> arabalistesi = new ArrayList<Arabalar>();
		arabalistesi.add(new Arabalar("Opel",10,13));
		arabalistesi.add(new Arabalar("Toyota",11,13));
		arabalistesi.add(new Arabalar("BMW",20,25));
		arabalistesi.add(new Arabalar("Mercedes",25,32));
		
		//17 TL kar
		//83 TL toplam satış fiyat
		
		int toplam=0;
		int kar2=0;
		for (int i=0;i<arabalistesi.size();i++) {
			toplam+=arabalistesi.get(i).getSatis();
			kar2+=arabalistesi.get(i).getSatis()-arabalistesi.get(i).getMaaliyet();
		}
		System.out.println(toplam);
		System.out.println("KAR : "+ kar2);
		
		
		int kar = arabalistesi.stream()
				.map(p->(p.getSatis() - p.getMaaliyet()))
				.reduce(0, (Integer a, Integer b)->(a+b))
				.intValue();
		
		System.out.println(kar);
		
		
		

	}

}
