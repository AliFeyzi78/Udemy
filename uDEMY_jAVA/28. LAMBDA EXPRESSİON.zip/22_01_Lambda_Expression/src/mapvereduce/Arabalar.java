package mapvereduce;

public class Arabalar {
	private String marka;
	private int maaliyet;
	private int satis;
	
	public Arabalar(String marka, int maaliyet, int satis) {
		this.marka = marka;
		this.maaliyet=maaliyet;
		this.satis=satis;
	}

	public String getMarka() {
		return marka;
	}

	public int getMaaliyet() {
		return maaliyet;
	}

	public int getSatis() {
		return satis;
	}
	
	
}
