package methodReferences;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Sinifim {

	public static List<String> listem = Arrays.asList("ali","ahmet","ayşe");
	
	public void normalMetot(String str) {
		System.out.println(str);
	}
	
	public static void statikMetot(String str) {
		System.out.println(str);
	}
	
	public static void main(String[] args) {
		Sinifim s = new Sinifim();
		
		listem.forEach(Sinifim::statikMetot); //method references
//		listem.forEach(s::normalMetot);
		
//		listem.forEach(System.out::println);
		
		
	}

}
