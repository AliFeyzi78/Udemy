package consumer;

import java.util.function.Consumer;

public class Main {

	public static void main(String[] args) {
		//Block java 7
		//Consumer 

		isimGetir(a->System.out.println(a), "Ahmet");
	}
	
	
	public static void isimGetir(Consumer<String> block,String param) {
		//.apply
		block.accept(param);
	}

}
