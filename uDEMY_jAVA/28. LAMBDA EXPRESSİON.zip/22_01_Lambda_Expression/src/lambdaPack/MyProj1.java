package lambdaPack;

import java.util.ArrayList;

public class MyProj1 {

	public static void main(String[] args) {
		
		Runnable thread1 = new Runnable() {
			@Override
			public void run() {
				System.out.println("kanal 1 çalıştı");	
			}
		};
		
		Runnable thread2=()->System.out.println("kanal2 çalıştı");
		thread2.run();
		
		Runnable thread3 = ()->{
			System.out.println("satir1");
			System.out.println("satir2");
		};
		thread3.run();

		
		
		ArrayList<String> dizi1 = new ArrayList();
		dizi1.add("Özgen");
		dizi1.add("Ahmet");
		dizi1.add("Sefa");
		
//		for(String str:dizi1) System.out.println(str);
//		
//		dizi1.forEach(System.out::println);
		
		dizi1.forEach((a)->System.out.println(a));
		
		dizi1.forEach((a)->{
			System.out.println(a);
			System.out.println(a.startsWith("A"));
		});
		

		
		

	}

}
