package pack3;

import java.util.function.Predicate;

public class Main {

	public static void main(String[] args) {
		Thread t1 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println("java");
				
			}
		});
		t1.start();
		
		
		Thread t2 = new Thread(()->{
			System.out.println("thread2");
		});
//		t2.start();
		t2.run();
		
		Runnable r1 = new Runnable() {
			
			@Override
			public void run() {
				System.out.println("r1");
				
			}
		};
		
		
		r1.run();
		
		
		Runnable r2 = Main::yazdir;
		r2.run();
		Thread t3 = new Thread(r2);
		t3.start();
				
		
		
		Runnable r10 = new Kanal10();
		
		new Thread(r10).start();
		new Thread(r10=Main::yazdir).start();
		
		r10.run();
	}
	
	
	public static void yazdir() {
		System.out.println("test metodu");
	}

}


class Kanal10 implements Runnable{
	public void run() {
		for (int i=0; i<5; i++) System.out.println("Merhaba");
	}
}
