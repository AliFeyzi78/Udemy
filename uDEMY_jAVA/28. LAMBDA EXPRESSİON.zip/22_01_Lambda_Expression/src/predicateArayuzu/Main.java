package predicateArayuzu;

import java.util.function.Predicate;

public class Main {

	public static void main(String[] args) {
		Predicate<Integer> p1 = p -> (p<20);
		System.out.println(p1.test(5));
		
		Predicate<String> p2 = str -> str.startsWith("a");
		System.out.println( p2.test("mehmet"));
		
		Predicate<String> p3 = str -> str.startsWith("a") && str.length()>5;
		System.out.println(p3.test("abdullah"));
		
		
	}

}
