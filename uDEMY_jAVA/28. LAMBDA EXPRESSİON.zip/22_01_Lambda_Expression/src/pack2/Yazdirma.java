package pack2;

public interface Yazdirma {
	public void yazdir();
}
