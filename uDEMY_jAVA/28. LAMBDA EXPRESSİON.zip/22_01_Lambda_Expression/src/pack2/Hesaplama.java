package pack2;

public interface Hesaplama {
	public int hesapla(int s1, int s2);
}
