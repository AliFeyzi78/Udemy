package pack2;

public class LambdaApp2 {

	public static void main(String[] args) {
		Yazdirma y1 = new Yazdirma() {
			
			@Override
			public void yazdir() {
				System.out.println("yazdir1");
				
			}
		};
		y1.yazdir();

		Yazdirma y2 = () -> {
			System.out.println("yazdir2");
			System.out.println("yazdir2 satir2");
		};
		y2.yazdir();
		
//		Hesaplama h1 = new Hesaplama() {
//			
//			@Override
//			public void hesapla(int s1, int s2) {
//				// TODO Auto-generated method stub
//				System.out.println(s1+s2);
//			}
//		};
//		h1.hesapla(10, 20);
		
		Hesaplama h2 = (int a,int b) -> {
			return a+b;
		};
		System.out.println(h2.hesapla(15, 23)); 
		
	}

}
