package streamArayuzu;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class Main {

	public static void main(String[] args) {
		Predicate<Integer> p1 = a->a<10;
		System.out.println(p1.test(5));
		
		List<Integer> numaralar = Arrays.asList(4,15,8,12,13,9,20,15,1);
		numaralar.stream().filter(p1).forEach(System.out::println);

		
	}

}
