package predicateArayuzu2;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class Ogrenciler {
	private String ogrenciAdi;
	private String cinsiyet;
	private int not;
	
	
	
	public String toString() {
		return ogrenciAdi +" "+cinsiyet +" "+ not + "\n";
	}
	
	public Ogrenciler(String ogrAdi, String cinsiyet, int not) {
		this.ogrenciAdi=ogrAdi;
		this.cinsiyet=cinsiyet;
		this.not=not;
	}
	
	public String getOgrenciAdi() {
		return ogrenciAdi;
	}
	public String getCinsiyet() {
		return cinsiyet;
	}
	public int getNot() {
		return not;
	}
	
	public static List<Ogrenciler> islem(List<Ogrenciler> ogrenciler, Predicate<Ogrenciler> predicate){
		List<Ogrenciler> list = new ArrayList<>();
		for(Ogrenciler ogr:ogrenciler) {
			if (predicate.test(ogr)) {
				list.add(ogr);
			}
		}
		return list;
	}
	
	
}
