package predicateArayuzu2;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		Ogrenciler ogr1 = new Ogrenciler("Ahmet", "erkek", 45);
		Ogrenciler ogr2 = new Ogrenciler("Mehmet", "erkek", 55);
		Ogrenciler ogr3 = new Ogrenciler("Ayşe", "kız", 65);
		Ogrenciler ogr4 = new Ogrenciler("Mustafa", "erkek", 40);
		Ogrenciler ogr5 = new Ogrenciler("Fatma", "kız", 45);
		Ogrenciler ogr6 = new Ogrenciler("Furkan", "erkek", 90);
		
		List<Ogrenciler> liste = new ArrayList<Ogrenciler>();
		liste.add(ogr1);
		liste.add(ogr2);
		liste.add(ogr3);
		liste.add(ogr4);
		liste.add(ogr5);
		liste.add(ogr6);
		
		List filtre = Ogrenciler.islem(liste, (Ogrenciler o)->o.getCinsiyet().equals("erkek") && o.getNot()>50);
		System.out.println(filtre);
		
		
		
		
		
	}

}
