package ornek1;

import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.Scanner;

public class Ornek1 {

	public static void main(String[] args) {
		double toplam=0;
		int intToplam = 0;
		try(Scanner scanner = new Scanner(new File("/users/ozgenimrag/test2/dosya6.txt"))){
			scanner.useLocale(Locale.US);
			System.out.println(scanner.locale());
			
			while(scanner.hasNextLine()) {
				System.out.println(scanner.nextLine());
//				if (scanner.hasNextDouble()) {
//					System.out.println("sayı double türde");
//					toplam+=scanner.nextDouble();
//				}
				
				if (scanner.hasNextInt())
					intToplam+=scanner.nextInt();
				
					
			}
			
			
			System.out.println("Toplam : "+toplam);
			System.out.println(intToplam);
		}catch(IOException e ) {
			
		}

	}

}
