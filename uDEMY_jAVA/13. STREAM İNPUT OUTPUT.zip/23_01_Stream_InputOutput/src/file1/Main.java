package file1;

import java.io.File;
import java.io.FileFilter;

public class Main {

	public static void main(String[] args) {
		//"c:/klasorAdi/dosyaAdi.txt"
		File file = new File("/users/ozgenimrag/test2/dosya1.txt");
		if (file.exists()) System.out.println("dosya var");
		else System.out.println("dosya yok");
		
		System.out.println("Dosyanın boyutu : " +file.length() +" byte");
		file.setWritable(false);
		System.out.println("dosya yazılabilir mi : "+ file.canWrite());
		file.setReadable(false);
		System.out.println("dosya okunabilir mi : "+ file.canRead());
		
		
		
//		DOSYANIN ADINI DEĞİŞTİRME VE DOSYA TAŞIMA İŞLEMİ
		
//		try {
//			boolean durum = file.renameTo(new File("/users/ozgenimrag/test2/dosya2.txt"));
//			if (durum) System.out.println("dosya adı başarıyla değiştirildi.");
//			else System.out.println("dosya adı değiştirme işleminde gerçekleşmedi.");
//		}catch(Exception e) {
//			System.out.println("Hata oluştu :"+e);
//		}
		
		
		
	}

}
