package dosyaKopyalama;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Kopyalama {

	public static void main(String[] args) {
		
		DataInputStream dis = null;
		DataOutputStream dos = null;
		
		try {
			dis = new DataInputStream(new FileInputStream(new File("/users/ozgenimrag/test2/sarki1.mp3")));
			dos=new DataOutputStream(new FileOutputStream(new File("/users/ozgenimrag/test2/yeniDosya.mp3")));
			int b;
			while ((b=dis.read()) != -1) {
				dos.write((byte)b);
			}
			
			dis.close();
			dos.close();
			
		}catch(IOException e) {
			
		}

	}

}
