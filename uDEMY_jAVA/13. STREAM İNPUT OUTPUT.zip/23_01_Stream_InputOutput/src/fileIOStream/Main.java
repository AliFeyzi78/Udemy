package fileIOStream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {

		String dosya1 = "/users/ozgenimrag/test2/dosya4.txt";
		File dosya = new File(dosya1);
		FileInputStream dosyaOku=null;
		FileOutputStream dosyaYaz = null;
		
		
		//-----KONTROL ET
		if (dosya.exists()==false) {
			try {
				dosya.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//---------------
		
		
		try {
			dosyaOku = new FileInputStream(dosya);
			//DOSYA OKUMA
			
//			System.out.print((char)dosyaOku.read());
			
			byte[] b = dosyaOku.readAllBytes();
			for (byte x:b) {
				System.out.print((char)x);
			}
			
			
			dosyaYaz = new FileOutputStream(dosya);
//			dosyaYaz.write(68);
//			dosyaYaz.write(110);
			
			String metin = "Deneme metniDeneme metniDeneme metniDeneme metni";
			byte[] bdizi = metin.getBytes();
			dosyaYaz.write(bdizi);
			dosyaYaz.flush(); 
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				dosyaOku.close();
				dosyaYaz.close();
			}
			catch(Exception e) {
				System.out.println(e);
			}
		}
		
	}

}
