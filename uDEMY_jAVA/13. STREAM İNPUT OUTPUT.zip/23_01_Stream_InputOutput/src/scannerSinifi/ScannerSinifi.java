package scannerSinifi;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Scanner;

public class ScannerSinifi {

	public static void main(String[] args) {
		
		try(PrintWriter pw = new PrintWriter(new File("/users/ozgenimrag/test2/dosya4.txt"))){
			pw.println("fadsfasdf");
			pw.println(23423);
			pw.println(43.6);
			pw.println("aa");
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		try (Scanner scanner = new Scanner(new File("/users/ozgenimrag/test2/dosya4.txt"))){



			while(scanner.hasNextLine()) {
				System.out.println(scanner.hasNextDouble());
				System.out.println(scanner.nextLine());
			}
			
			
		}catch(FileNotFoundException e) {
			
		}

	}

}
