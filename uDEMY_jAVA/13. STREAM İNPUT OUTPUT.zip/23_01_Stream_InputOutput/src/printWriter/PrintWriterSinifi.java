package printWriter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class PrintWriterSinifi {

	public static void main(String[] args) {
		//PrintWriter
		PrintWriter pw=null;
		
		try {
			pw = new PrintWriter(new File("/users/ozgenimrag/test2/dosya4.txt"));
			pw.write(68); //D
			pw.write("\n");
			char[] karakterDizisi= {'j','a','v','a'};
			pw.write(karakterDizisi);
			pw.write("Deneme metni");
			
			pw.append('A');
			pw.print("herkese merhaba");
			pw.println("printwriter sınıfı");
			pw.println("sdfadsf");
			
			pw.println(3.7);
			pw.println(true);
			
			
			//Her string ifade bir diziyi temsil eder. Karakter dizisi
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if (pw!=null)
				pw.close();
		}

	}

}
