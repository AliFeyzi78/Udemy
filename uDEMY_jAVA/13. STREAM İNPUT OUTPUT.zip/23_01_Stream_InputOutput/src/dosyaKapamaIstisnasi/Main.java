package dosyaKapamaIstisnasi;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		
		FileInputStream dosyaOku1=null;
		FileOutputStream dosyaYaz1 = null;
		
		try {
//			dosyaOku1 = new FileInputStream("/users/ozgenimrag/test2/dosya4.txt");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (dosyaOku1!=null)
					dosyaOku1.close();
				if (dosyaYaz1!=null)
					dosyaYaz1.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
