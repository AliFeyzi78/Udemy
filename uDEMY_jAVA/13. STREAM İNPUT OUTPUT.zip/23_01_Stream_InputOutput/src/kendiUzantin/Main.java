package kendiUzantin;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		File dosya = new File("/users/ozgenimrag/test2/dosya5.zgn");
		if (dosya.exists()==false) {
			try {
				dosya.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		try(PrintWriter writer = new PrintWriter(dosya)){
			writer.println("kendi uzantımız");
		}catch(FileNotFoundException e) {
			
		}
		
		try(Scanner reader = new Scanner(dosya)){
			while(reader.hasNextLine())
				System.out.println(reader.nextLine());
		}catch(FileNotFoundException e) {
			
		}
			

	}

}
