package filtreleme;

import java.io.File;
import java.io.FilenameFilter;

public class Main implements FilenameFilter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File file = new File("/users/ozgenimrag/test2");
		for(File f:file.listFiles(new Main())) {
			System.out.println(f);
		}
		
		String[] liste = new File("/users/ozgenimrag/test2").list();
		for (String str:liste) {
			if (str.endsWith(".png"))
				System.out.println(str);
		}
		
	}

	@Override
	public boolean accept(File f, String dosya) {
		// TODO Auto-generated method stub
		return dosya.endsWith(".txt");
	}

}
