package listeleme;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.Date;

public class Main{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String yol = "/users/ozgenimrag/test2";
		
		//list() -> listeyi string olarak döndürür.
		//listFiles() -> listeyi File
		
		String[] liste1 = new File(yol).list();
		File[] liste2 = new File(yol).listFiles();
		
		
		//sadece klasörleri listele
		for(File str:liste2) {
			if (!str.isFile()) System.out.println(str.getName());
			
		}
		
		
		
	}

	

}
