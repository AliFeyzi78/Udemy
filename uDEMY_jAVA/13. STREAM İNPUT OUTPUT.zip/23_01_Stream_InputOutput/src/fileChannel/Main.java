package fileChannel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

public class Main {

	public static void main(String[] args) {
		
		
		File kaynakDosyam, hedefDosyam;
		kaynakDosyam=new File("/users/ozgenimrag/test2/dosya6.txt");
		hedefDosyam=new File("/users/ozgenimrag/test2/yeniDosya2.txt");
		
		try {
			kopyala(kaynakDosyam, hedefDosyam);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	
	
	public static void kopyala(File kaynak, File hedef) throws IOException{
		FileChannel k =null;
		FileChannel h=null;
		
		k=new FileInputStream(kaynak).getChannel();
		h=new FileOutputStream(hedef).getChannel();
		h.transferFrom(k, 0, k.size());
		
		if (k!=null) {
			k.close();
		}
		if (h!=null)h.close();
	}

}
