import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FocusTraversalPolicy;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.SortingFocusTraversalPolicy;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.plaf.basic.BasicBorders.MarginBorder;
import javax.swing.text.Caret;
import javax.swing.SwingUtilities;
import javafx.scene.Cursor;

import javax.swing.JList;
import javax.swing.JComboBox;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;

public class SwingProp1 {

	private JFrame frame;
	private JTextField txtTextHere;
	private JTextField textField2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingProp1 window = new SwingProp1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SwingProp1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	@SuppressWarnings("deprecation")
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		txtTextHere = new JTextField();
		
		java.awt.Cursor c = new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR);
		txtTextHere.setCursor(c);
		txtTextHere.setText("ÖZGEN");
		//txtTextHere.setEnabled(false);
		txtTextHere.setDisabledTextColor(Color.RED);
		
		
	
		txtTextHere.setBounds(61, 104, 130, 29);
		frame.getContentPane().add(txtTextHere);
		txtTextHere.setColumns(10);
		
		JButton btn1 = new JButton("Button1");
		btn1.setBounds(61, 176, 117, 29);
		frame.getContentPane().add(btn1);
		
		//btn1.setSize(200, 80);
		btn1.setSize(new Dimension(200,100));
		
		textField2 = new JTextField();
		textField2.setBounds(215, 105, 130, 26);
		frame.getContentPane().add(textField2);
		textField2.setColumns(10);
		
		
		
		txtTextHere.setNextFocusableComponent(btn1);
		btn1.setNextFocusableComponent(textField2);
		textField2.setNextFocusableComponent(txtTextHere);
		//focusTraversalPolicy set get
		
		
	}
}
