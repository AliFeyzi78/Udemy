import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class SwingApp2 implements ActionListener {
	
	static JButton btn1,btn2;

	
	SwingApp2(){
		JFrame frame = new JFrame("My Window");
		frame.setSize(400,300);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new FlowLayout());
	
		
		btn1 = new JButton("Button1");
		btn2 = new JButton("Button2");
		
		frame.add(btn1);
		frame.add(btn2);
	
		btn1.addActionListener(this);
		btn2.addActionListener(this);

	}
	
	@Override
	public void actionPerformed(ActionEvent a) {
		// TODO Auto-generated method stub
		
		if (a.getActionCommand().equals("Button1"))
				btn1.setText("btn1 clicked");
		else if (a.getActionCommand().equals("Button2"))
			btn2.setText("btn2 clicked");
		
		
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new SwingApp2();
			}
		});
		
		
		
	}



	

}
