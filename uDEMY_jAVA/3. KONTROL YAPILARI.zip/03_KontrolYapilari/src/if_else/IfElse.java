package if_else;

public class IfElse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//if
		
		Boolean var1 = false;
		
		Integer a,b;
		a = 8;
		b=5;
		if (a<b)
		{
			System.out.println("a < b");
		}
		
		
		//if else
		
		Integer c,d;
		c=8;
		d=5;
		
		if (c<d)
		{
			System.out.println("c < d");
		}
		else if (c==d)
		{
			System.out.println("c = d");
		}
		else
		{
			System.out.println("c > d");
		}
		
		if (c > d) System.out.println("ok");
		
		
		
		
		

	}

}
