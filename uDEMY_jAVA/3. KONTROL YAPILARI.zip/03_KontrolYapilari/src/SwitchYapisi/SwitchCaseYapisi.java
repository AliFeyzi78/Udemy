package SwitchYapisi;

public class SwitchCaseYapisi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Integer x =3;
		
		switch (x)
		{
		case 2:
			System.out.println("2");
			break;
		case 3:
			System.out.println("3");
			break;
		default:
			System.out.println("any");
			break;
		}

		
		String str1 = "en";
		switch (str1)
		{
		case "ahmet":
			System.out.println("ahmet");
			break;
		case "Özgen":
			System.out.println("Özgen");
			break;
		default:
			System.out.println("any");
			break;
				
			
		}
		
		
		
		
		
		
		
	}

}
