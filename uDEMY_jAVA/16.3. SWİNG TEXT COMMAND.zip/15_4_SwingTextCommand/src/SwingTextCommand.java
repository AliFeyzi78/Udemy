import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;

public class SwingTextCommand implements ActionListener {

	private JFrame frame;
	JLabel label1;
	private JTextField tf1;
	private JTextField tf2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingTextCommand window = new SwingTextCommand();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SwingTextCommand() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		label1 = new JLabel("New label");
		label1.setBounds(136, 44, 223, 16);
		frame.getContentPane().add(label1);
		
		JButton btn1 = new JButton("Button1");
		btn1.setBounds(38, 90, 117, 29);
		frame.getContentPane().add(btn1);
		btn1.addActionListener(this);
		
		JButton btn2 = new JButton("Button2");
		btn2.setBounds(211, 90, 117, 29);
		frame.getContentPane().add(btn2);
		
		tf1 = new JTextField();
		tf1.setBounds(25, 131, 130, 26);
		frame.getContentPane().add(tf1);
		tf1.setColumns(10);
		tf1.setActionCommand("t1");
		tf1.addActionListener(this);
		
		tf2 = new JTextField();
		tf2.setBounds(211, 131, 130, 26);
		frame.getContentPane().add(tf2);
		tf2.setColumns(10);
		tf2.setActionCommand("t2");
		tf2.addActionListener(this);
		btn2.addActionListener(this);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent a) {
		// TODO Auto-generated method stub
		
		if (a.getActionCommand().equals("Button1"))
			label1.setText("button1 clicked");
		else if (a.getActionCommand().equals("Button2"))
			label1.setText("button2 clicked");
		
		if(a.getActionCommand().equals("t1"))
			label1.setText("textfield1");
		else if (a.getActionCommand().equals("t2"))
			label1.setText("textfield2");
		
		
	}

}
