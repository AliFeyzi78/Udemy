import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class SwingLabelHtml {
	
	String list1;

	private JFrame frame;
	private JTextField txt1;
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingLabelHtml window = new SwingLabelHtml();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SwingLabelHtml() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		txt1 = new JTextField();
		txt1.setBounds(25, 33, 130, 26);
		frame.getContentPane().add(txt1);
		txt1.setColumns(10);
		
		list1 = "";
		
		JButton btnAdd = new JButton("Add");
		
		btnAdd.setBounds(25, 71, 117, 29);
		frame.getContentPane().add(btnAdd);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(234, 118, 99, 84);
		frame.getContentPane().add(scrollPane);
		
		JLabel labelList = new JLabel("New label");
		scrollPane.setViewportView(labelList);
		
		//-------SET DEFAULT BUTTON 
		frame.getRootPane().setDefaultButton(btnAdd);
		
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				list1+= txt1.getText()+"<br>";
				labelList.setText("<html>"+list1);
				txt1.setText("");
			}
		});
	}

}
