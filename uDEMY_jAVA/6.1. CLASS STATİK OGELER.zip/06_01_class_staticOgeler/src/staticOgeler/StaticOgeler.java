package staticOgeler;

public class StaticOgeler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		PrintText1 pt1 = new PrintText1();
//		pt1.printText1x();
		
//		PrintText2.PrintText2x();
		
		
		St st1 = new St();
		st1.a = 12;
		st1.b = 13;
		
		
		
		St st2 = new St();
		st2.a = 22;
		st2.b = 23;
		
		System.out.println(st1.a);
		System.out.println(st1.b);
		
		System.out.println("---");
		
		
		System.out.println(st2.a);
		System.out.println(st2.b);
		
	}
	
}

class PrintText1{
	public void printText1x() {
		System.out.println("Özgen İMRAĞ");
	}
}

class PrintText2{
	static void PrintText2x() {
		System.out.println("Özgen İMRAĞ");
	}
}



class St
{
	public int a;
	public static int b;
}


