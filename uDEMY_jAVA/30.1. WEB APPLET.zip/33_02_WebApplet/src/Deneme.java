import java.awt.Graphics;

import javax.swing.JApplet;

public class Deneme extends JApplet {

	/**
	 * Create the applet.
	 */
	public Deneme() {
		this.setSize(200, 200);
	}
	
	public void paint(Graphics g) {
		g.drawString("deneme metni", 20, 30);
	}
	
	public void init() {
		super.init();
	}

}
