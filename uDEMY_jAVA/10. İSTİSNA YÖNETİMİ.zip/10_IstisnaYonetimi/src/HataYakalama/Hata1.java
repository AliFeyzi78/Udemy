package HataYakalama;

public class Hata1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// 1- Syntax error tr-> sözdizimi hatası
		//inxt d;
		
		// 2- Logical error tr-> mantıksal hatalar
		//int d="Özgen";
		
		// 3- Run-time error tr-> çalışma zamanı hatası
		
		int a;
		a=5/0;
		
		System.out.println("5 / 0 = "+ a);
		System.out.println("Özgen İMRAĞ");
		
		//java.lang.ArithmeticException
	}

}


