package hata3;

public class Hata3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//try catch finally
		
		try
		{
			int a = 7/0;
			
		}
		catch(Exception e)
		{
			System.out.println("ERROR -> "+ e);
			return;
		}
		finally
		{
			System.out.println("FINALLY");
			
		}
		
		System.out.println("TEST");
	}

}


