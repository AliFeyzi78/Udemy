package try_catch;

public class TryCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try
		{
			int a;
			a=5/0;
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);		
			System.out.println("ERROR");
		}

		
		System.out.println("END");
	}

}
