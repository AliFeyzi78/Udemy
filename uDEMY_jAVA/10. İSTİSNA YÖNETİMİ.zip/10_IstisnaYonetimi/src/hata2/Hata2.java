package hata2;

public class Hata2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//throw
		
		MyClass a= new MyClass();
		
		
		try
		{
			a.divid();
		}
		catch(ArithmeticException e)
		{
			System.out.println("ERROR 2  -> "+ e);
		}
	}
}

class MyClass
{
	static void divid()
	{
		try
		{
			int a=5/0;
		}
		catch(ArithmeticException e)
		{
			System.out.println("error in class");
			throw(e);
		}
	}
}
