package tryWithResources;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class Main {

	public static void main(String[] args) {
		
//		BufferedWriter writer=null;
//		
//		try {
//			writer = new BufferedWriter(new FileWriter("/users/ozgenimrag/test2/dosya1.txt"));
//			writer.write("özgen imrağ");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		finally {
//			try {
//				writer.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
		
		
		//try with resources socket, io işlemleri, veritabanı 
		
		try(BufferedWriter writer = new BufferedWriter(new FileWriter("/users/ozgenimrag/test2/dosya1.txt"))){
			writer.write("deneme metni");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
//		try(Test t = new Test()){   -> HATA
//			t.yazdir();
//		} catch(Exception e) {
//			
//		}
		
		
		//STREAM input stream(okuma) - output stream(yazma)
		

	}

}
