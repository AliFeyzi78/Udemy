package tryWithResources;

public class Test {
	public void yazdir() {
		System.out.println("herkese selam");
	}
}
