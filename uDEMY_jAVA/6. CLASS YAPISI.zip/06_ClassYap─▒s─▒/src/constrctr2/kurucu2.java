package constrctr2;



public class kurucu2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bolme islem = new Bolme(10,6);
	}
	
	
}

class Bolme
{
	
	int x,y;
	double sonuc;
	
	public Bolme(int a, int b)
	{
		x=a;
		y=b;
		
		if (y==0)
		{
			System.out.println("bölen 0 olamaz");
			return;
		}
		else
			sonuc = (double)(x)/(double)(y);
		
		System.out.println(sonuc);
	}
}






