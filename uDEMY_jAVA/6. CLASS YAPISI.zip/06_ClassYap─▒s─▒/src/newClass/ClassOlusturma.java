package newClass;

public class ClassOlusturma {
	
	/* 	METHOD
	 * hızlanma
	 * yavaslama
	 */
	
	/*  PROPERTY
	 * model
	 * hız
	 * max hız
	 */
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Car car1=new Car("Toyota",220);
		
		System.out.println(car1.getModel());
		System.out.println(car1.getMaxSpeed());
		car1.acceleration();
		System.out.println(car1.getSpeed());
		
	
		
		
	}
	
	
}

class Car
{
	private String model;
	private int speed, maxSpeed;
	
	public Car(String model,int maxSpeed)
	{
		this.model = model;
		this.maxSpeed = maxSpeed;
		this.speed = 0;
	}
	
	public int getSpeed() {
		return speed;
	}
	
	

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public int getMaxSpeed() {
		return maxSpeed;
	}

	public void setMaxSpeed(int maxSpeed) {
		this.maxSpeed = maxSpeed;
	}

	public void acceleration()  // TR -> hizlanma
	{
		if (speed<maxSpeed)
			speed+=10;
	}
	
	public void slowdown()   // TR -> yavaşlama
	{
		if (speed>0)
			speed-=10;
	}
	
	public String getModel() {
		return model;
	}
	
	public void setModel(String model) {
		this.model = model;
	}
	
	
	
	
}



