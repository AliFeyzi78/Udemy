package packTimer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.JSpinner;

public class MainTimer {

	private JFrame frame;
	static int i = 0;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainTimer window = new MainTimer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public MainTimer() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblTimer = new JLabel("0");
		JButton btnStart = new JButton("Start");
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Timer
				// TimerTask

				i = 0;
				Timer timer = new Timer();
				
				TimerTask task = new TimerTask() {

					@Override
					public void run() {
						i++;
						if (i == 7)
							timer.cancel();
						lblTimer.setText(String.valueOf(i));

					}
				};
				timer.schedule(task, 1000, 1000);
			}
		});
		btnStart.setBounds(131, 110, 117, 29);
		frame.getContentPane().add(btnStart);

		lblTimer.setBounds(160, 162, 61, 16);
		frame.getContentPane().add(lblTimer);
		
		
	}
}
