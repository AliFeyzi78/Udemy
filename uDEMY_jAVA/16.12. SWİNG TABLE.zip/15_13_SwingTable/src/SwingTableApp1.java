import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JLabel;

public class SwingTableApp1 {

	private JFrame frame;
	private JTable table;
	
	ListSelectionModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingTableApp1 window = new SwingTableApp1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SwingTableApp1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 551, 392);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		String [] head = {"name","mail","age"};
		
		Object[][] data = {
				{"Özgen","ozgen@gmail.com",27},
				{"Gökhan","gokhan@gmail.com",30},
				{"Özgen","ozgen@gmail.com",27},
				{"Gökhan","gokhan@gmail.com",30},
				{"Özgen","ozgen@gmail.com",27},
				{"Gökhan","gokhan@gmail.com",30},
				{"Özgen","ozgen@gmail.com",27},
				{"Gökhan","gokhan@gmail.com",30}
		};
		
		
		
		table = new JTable(data,head);
		JScrollPane jscroll = new JScrollPane(table);
		jscroll.setBounds(57, 74, 218, 99);
		frame.getContentPane().add(jscroll);
		
		
		table.setGridColor(Color.RED);
		
		JLabel label = new JLabel("New label");
		label.setBounds(79, 198, 61, 16);
		frame.getContentPane().add(label);
		model = table.getSelectionModel();
		model.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				// TODO Auto-generated method stub
				int selectedRow = table.getSelectedRow();
				int selectedCol = table.getSelectedColumn();
				
				label.setText(String.valueOf( data[selectedRow][selectedCol]));

				
			}
		});
	}
}
