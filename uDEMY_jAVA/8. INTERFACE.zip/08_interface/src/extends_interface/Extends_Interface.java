package extends_interface;

public class Extends_Interface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
	}

}

interface face1
{
	void show1();
}

interface face2 extends face1
{
	void show2();
}

class A implements face2
{
	public void show1()
	{
		System.out.println("show1 method");
	}
	
	public void show2()
	{
		System.out.println("show2 method");
	}
}


