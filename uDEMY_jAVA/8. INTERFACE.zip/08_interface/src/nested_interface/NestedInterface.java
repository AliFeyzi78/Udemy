package nested_interface;


public class NestedInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Nested Interface
		
		A.myInterface obj1 = new B("Özgen İMRAĞ");
		System.out.println(obj1.getName());
	}

}

class A
{
	public interface myInterface
	{
		String getName();
	}
}


class B implements A.myInterface
{
	String name;
	
	B(String txt){
		name = txt;
	}
	
	public String getName() {
		return name;
	}
}


