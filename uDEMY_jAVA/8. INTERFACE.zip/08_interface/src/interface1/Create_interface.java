package interface1;

public class Create_interface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//interface  -> TR- arabirim/arayüz
		
		myInterface obj1 = new MyClass();
		System.out.println( obj1.getName());
		
		
		
		
	}

}

interface myInterface
{
	String getName();
	
}

class MyClass implements myInterface
{
	public String getName()
	{
		return "Özgen İMRAĞ";
	}
}









