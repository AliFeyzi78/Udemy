package sample1_interface;

public class ClassInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		mathInterface obj1 = new MathClass(18,6);
		System.out.println(obj1.plus());
		System.out.println(obj1.minus());
		System.out.println(obj1.dividedBy());
		System.out.println(obj1.multiply());

	}

}


interface mathInterface
{
	int plus(); // TR-> topla
	int minus(); // TR-> çıkar
	int dividedBy(); // TR-> bölme
	int multiply(); // TR-> çarpma
}

class MathClass implements mathInterface
{
	int a, b;
	
	MathClass(int x, int y)
	{
		a=x;
		b=y;
	}
	
	public int plus()
	{
		return a+b;
	}
	
	public int minus()
	{
		return a-b;
	}
	
	public int dividedBy()
	{
		return a/b;
	}
	
	public int multiply()
	{
		return a*b;
	}
}
