package sample2_interface;

public class Sample2Interface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		AutomaticCar oto1 = new AutomaticCar();
//		oto1.run();
//		oto1.faster();
//		System.out.println(oto1.getSpeed());
		
		
		ManuelCar oto2 = new ManuelCar();
		oto2.run();
		oto2.shift1();
		oto2.faster();
		oto2.faster();
		System.out.println(oto2.getSpeed());
		
	}

}

interface carPro
{
	void run(); // tr-> motoru çalıştır.
	void faster(); // tr-> hızlan.
	
	int getSpeed(); // tr-> hız değerini getir.
}

interface manuelGear
{
	void shift1(); // tr-> vitesi 1'e al 
}

class AutomaticCar implements carPro
{
	Boolean runStatus;
	int speed;
	
	AutomaticCar()
	{
		runStatus=false;
		speed=0;
	}
	
	public void run()
	{
		runStatus = true;
		System.out.println("engine run SUCCESS");
	}
	
	public void faster()
	{
		if (runStatus)
			speed++;
		else
			System.out.println("engine not run");
		
	}
	
	public int getSpeed()
	{
		return speed;
	}
	
}


class ManuelCar extends AutomaticCar implements manuelGear
{
	int gear; //tr-> vites
	
	public void shift1()
	{
		gear = 1;
	}
	
	public void faster()
	{
		if (runStatus)
		{
			if (gear == 1)
			{
				speed++;
			}
			else System.out.println("gear = 0 !!!");
		}
		else System.out.println("engine not run !!!");
	}
	
	
}


