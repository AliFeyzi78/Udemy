import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;

public class CheckApp implements ActionListener {

	private JFrame frame;
	
	JRadioButton r1,r2,r3;
	JLabel labelRadio;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CheckApp window = new CheckApp();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CheckApp() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	
	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JCheckBox ch1 = new JCheckBox("All Select");
		
		ch1.setBounds(25, 45, 128, 23);
		frame.getContentPane().add(ch1);
		
		JLabel label1 = new JLabel("New label");
		label1.setBounds(35, 69, 128, 16);
		frame.getContentPane().add(label1);
		
		JCheckBox ch2 = new JCheckBox("New check box");
		ch2.setBounds(25, 97, 128, 23);
		frame.getContentPane().add(ch2);
		
		JCheckBox ch3 = new JCheckBox("New check box");
		ch3.setBounds(25, 121, 128, 23);
		frame.getContentPane().add(ch3);
		
		JCheckBox ch4 = new JCheckBox("New check box");
		ch4.setBounds(25, 146, 128, 23);
		frame.getContentPane().add(ch4);
		
		JCheckBox checkEnable = new JCheckBox("enable");
		checkEnable.setSelected(true);
		checkEnable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (checkEnable.isSelected())
				{
					r1.setEnabled(true);
					r2.setEnabled(true);
					r3.setEnabled(true);
				}
				else
				{
					r1.setEnabled(false);
					r2.setEnabled(false);
					r3.setEnabled(false);
				}
			}
		});
		checkEnable.setBounds(227, 45, 128, 23);
		frame.getContentPane().add(checkEnable);
		
		labelRadio = new JLabel("New label");
		labelRadio.setBounds(237, 69, 61, 16);
		frame.getContentPane().add(labelRadio);
		
		
		
		r1 = new JRadioButton("Radio Button 1");
		r1.addActionListener(this);
		r1.setBounds(227, 97, 141, 23);
		frame.getContentPane().add(r1);
		
		r2 = new JRadioButton("Radio Button 2");
		r2.addActionListener(this);
		r2.setBounds(227, 121, 141, 23);
		frame.getContentPane().add(r2);
		
		r3 = new JRadioButton("Radio Button 3");
		r3.addActionListener(this);
		r3.setBounds(227, 146, 141, 23);
		frame.getContentPane().add(r3);
		
		ButtonGroup group1 = new ButtonGroup();
		group1.add(r1);
		group1.add(r2);
		group1.add(r3);
		
		
		
		ch1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				label1.setText(String.valueOf( ch1.isSelected()));
				
				if (ch1.isSelected()) {
					ch2.setSelected(true);
					ch3.setSelected(true);
					ch4.setSelected(true);
				} else {
					ch2.setSelected(false);
					ch3.setSelected(false);
					ch4.setSelected(false);
				}
			}
		});
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if (r1.isSelected()) 	labelRadio.setText("R1");
		else if (r2.isSelected()) 	labelRadio.setText("R2");
		else if (r3.isSelected()) 	labelRadio.setText("R3");
	}

}
