package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class SampleController implements Initializable {
	
	Connection con;
	
	String strName,strAge;
	Boolean married;
	
	@FXML
	private TableView<Persons> table;
	
	@FXML
	private TableColumn<Persons, String> name;
	
	@FXML
	private TableColumn<Persons, Integer> age;
	
	@FXML
	private TableColumn<Persons, Boolean> status;
	
	@FXML
	private TextField txt_name,txt_age;
	
	@FXML 
	private CheckBox ch_married;
	
	
	
	
	ObservableList<Persons> list = FXCollections.observableArrayList();
	
	

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		
		try {
			con=Connector.getConnection();
			
			ResultSet rs = con.createStatement().executeQuery("select * from table_personnel");
			while(rs.next()) {
				list.add(new Persons(rs.getString("name"),rs.getInt("age"),rs.getBoolean("status")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		name.setCellValueFactory(new PropertyValueFactory<>("name"));
		age.setCellValueFactory(new PropertyValueFactory<>("age"));
		status.setCellValueFactory(new PropertyValueFactory<>("status"));
		
		table.setItems(list);
		
		
		
	}
	
	
	public void btnSave_click() {
		strName=txt_name.getText().toString();
		strAge=txt_age.getText().toString();
		married = ch_married.isSelected();
		
		try {
			Statement st = con.createStatement();
			String addQuery = "insert into table_personnel (name,age,status) values ('"+strName+"',"+strAge+","+married+")";
			st.execute(addQuery);
			
			list.clear();
			ResultSet rs2 = con.createStatement().executeQuery("select * from table_personnel");
			while (rs2.next()) {
				list.add(new Persons(rs2.getString("name"),rs2.getInt("age"),rs2.getBoolean("status")));
			}
			
			table.setItems(list);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void table_click() {
		System.out.println(table.getSelectionModel().getSelectedItem().getName());
	}
	
	public void btnDelete_click(){
		try {
			Statement st = con.createStatement();
			String deleteQuery = "delete from table_personnel where name='"+table.getSelectionModel().getSelectedItem().getName()+"'";
			st.execute(deleteQuery);
			
			list.clear();
			ResultSet rs2 = con.createStatement().executeQuery("select * from table_personnel");
			while (rs2.next()) {
				list.add(new Persons(rs2.getString("name"),rs2.getInt("age"),rs2.getBoolean("status")));
			}
			
			table.setItems(list);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
