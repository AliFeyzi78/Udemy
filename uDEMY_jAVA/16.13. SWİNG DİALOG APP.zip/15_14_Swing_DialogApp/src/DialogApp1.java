import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DialogApp1 {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DialogApp1 window = new DialogApp1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DialogApp1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label1 = new JLabel("New label");
		
		JButton btnShowDialog = new JButton("show dialog");
		btnShowDialog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(frame, "java","title",JOptionPane.WARNING_MESSAGE);
				
				label1.setText("dialog closed");
				
			}
		});
		btnShowDialog.setBounds(24, 50, 117, 29);
		frame.getContentPane().add(btnShowDialog);
		
		
		label1.setBounds(44, 96, 142, 16);
		frame.getContentPane().add(label1);
		
		JLabel label2 = new JLabel("New label");
		JButton btnDialog = new JButton("dialog 2");
		btnDialog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int r = JOptionPane.showConfirmDialog(frame, "java");
				switch (r) {
				case 2:
					label2.setText("cancel clicked");
					break;
				case 1:
					label2.setText("no clicked");
					break;
				case 0:
					label2.setText("yes clicked");
					break;
				default:
					break;
				}
			}
		});
		btnDialog.setBounds(148, 50, 117, 29);
		frame.getContentPane().add(btnDialog);
		
		
		label2.setBounds(158, 96, 61, 16);
		frame.getContentPane().add(label2);
		
		JLabel label3 = new JLabel("New label");
		label3.setBounds(289, 96, 61, 16);
		frame.getContentPane().add(label3);
		
		JButton button3 = new JButton("New button");
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String inputData = JOptionPane.showInputDialog("name");
				
				if(inputData==null)
					label3.setText("cancelled");
				else label3.setText(inputData);
			}
		});
		button3.setBounds(267, 50, 117, 29);
		frame.getContentPane().add(button3);
		
		JLabel label4 = new JLabel("New label");
		label4.setBounds(46, 183, 61, 16);
		frame.getContentPane().add(label4);
		
		JButton button4 = new JButton("New button");
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String [] teams = {"arsenal","real madrid","barcelona"};
				String team = (String)JOptionPane.showInputDialog(frame,"select team","title",JOptionPane.QUESTION_MESSAGE,null,teams,"arsenal");
				label4.setText(team);
				
			}
		});
		button4.setBounds(24, 145, 117, 29);
		frame.getContentPane().add(button4);
	}
}
