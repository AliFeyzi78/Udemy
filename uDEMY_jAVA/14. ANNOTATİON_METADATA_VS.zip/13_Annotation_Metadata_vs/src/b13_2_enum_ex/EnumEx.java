package b13_2_enum_ex;

public class EnumEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int topGain = 0;
		
		Products tea = Products.Tea;
		System.out.println(tea.getPrice());
		System.out.println(tea.getStock());
		
		tea.sales();
		tea.sales();
		tea.sales();
		tea.sales();
		tea.sales();
		tea.sales();
		tea.sales();
		tea.sales();
		tea.sales();
		tea.sales();
		tea.sales();
		tea.sales();
		
		System.out.println(tea.getStock());
		
		Products.valueOf("Banana").sales();
		System.out.println(Products.Banana.getStock());
		
		tea.getGain();
		Products.valueOf("Banana").getGain();
		
		for(int i=0;i<5;i++) {
			topGain += Products.values()[i].getGain();
		}
		
		System.out.println("top gain -> "+topGain);
		
		
		
	}

}
