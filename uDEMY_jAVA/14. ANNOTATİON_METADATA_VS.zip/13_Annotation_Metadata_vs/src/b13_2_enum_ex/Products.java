package b13_2_enum_ex;

public enum Products {
	Tea(2,10),Coffee(3,10),Cracker(1,10),Banana(4,10),Grape(5,10);
	
	private int price;
	private int stock;
	private int gain=0;
	
	Products(int p, int s){
		price = p;
		stock = s;
	}
	
	public int getPrice() {
		return price;
	}
	
	public int getStock() {
		return stock;
	}
	
	public void sales() {
		
		if(this.stock>0)
		{
			this.stock--;
			gain+=this.getPrice();
		}
		else
			System.out.println("no product");
	}
	
	public void sales(String prod) {
		if(this.stock>0)
		{
			Products.valueOf(prod).stock--;
			gain+=this.getPrice();
		}
		else
			System.out.println("no product");
	}
	
	
	public int getGain() {
		return gain;
	}

}

