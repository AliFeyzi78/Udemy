package b13_4;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;

@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@interface Info{
	String author();
	String date() default "2020";
}

@interface Anno2{
	int value();
	
}


@Info(author="Özgen", date="2018")
class A{
	@Info(author="Gokhan")
	public void mt() {
		System.out.println("java");
	}
}





public class MetaData1 {
	

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		//source
		//class
		//runtime
		
		
		Class<A> cl = A.class;
		Annotation an = cl.getAnnotation(Info.class);
		Info in =(Info)an;
		System.out.println("Author -> "+in.author()+"   "+ "Date -> "+in.date());
		
		
		try {
			Method m = A.class.getMethod("mt");
			Annotation a2 = m.getAnnotation(Info.class);
			Info i2 = (Info)a2;
			System.out.println("Author -> "+i2.author()+"   "+"Date -> "+i2.date());
			
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}
	



}









