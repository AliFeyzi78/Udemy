package b13_3;

public class BoxUnbox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//unboxing boxing
		
		int a = 5; //primitif
		Integer b = 6; //referance
		
		Integer d = 10;
		int e = d.intValue();  //unboxing
		
		
		System.out.println(a+b);
		
		System.out.println("----");
		
		
		Integer i1 = 128;
		int i2 = i1.byteValue();
		System.out.println(i2);
		
		//byte -> -128 ... 127
		
	}

}
