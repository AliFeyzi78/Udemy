package b13_1;

public class B13_Enum {
	
	public enum Mounth{
		January(1), Fabruary, March(3,"abc"), April(4);
		
		private int mIndex;
		private String str;
		
		Mounth(){
			
		}
		
		Mounth(int ind){
			mIndex = ind;
		}
		
		Mounth(int ind, String s){
			mIndex = ind;
			str = s;
		}
		
		public int getIndex() {
			return mIndex;
		}
		
		public String getStr() {
			return str;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		System.out.println(Mounth.Fabruary.getIndex());
		System.out.println(Mounth.March.getStr());
		
		
		
	}

}
