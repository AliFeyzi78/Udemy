package create_generic2;

public class generic1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyClass<Integer> obj1 = new MyClass<Integer>(4);
		System.out.println(obj1.result());
		obj1.getType();
		
		MyClass<Double> obj2 = new MyClass<Double>(3.5);
		obj2.getType();
	}

}

class MyClass<T>
{
	T i;
	
	MyClass(T i){
		this.i=i;
	}
	
	T result() {
		return i;
	}
	
	void getType() {
		System.out.println(i.getClass().getName());
	}
}



