package generic_method;


public class GenericMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	
		Integer[] numbers = {3,5,6,9,15};
		String [] txt = {"Besiktas", "Galatasaray", "Fenerbahce"};
		Double[] numbers2 = {3.4, 4.5, 1.7};
		
		show(numbers);
		show(txt);
		show(numbers2);
	}
	
	
	public static <T> void show(T[] list)
	{
		for (T x: list) {
			System.out.println(x);
		}
	}


}


