package generikMultiParameter;


public class GenericMultiParam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyClass<Integer, Byte> obj1 = new MyClass<Integer, Byte>(10,(byte)3);
		obj1.getTypes();
		
		Object obj = 3;
		System.out.println(obj.getClass().getName());
		
	}
	

}


class MyClass<T1 extends Number,T2 extends Number>
{
	T1 i1;
	T2 i2;
	
	MyClass(T1 i1, T2 i2){
		this.i1 = i1;
		this.i2 = i2;
	}
	
	void getTypes() {
		System.out.println(i1+ " -> "+ i1.getClass().getName());
		System.out.println(i2+ " -> "+ i2.getClass().getName());
	}
}