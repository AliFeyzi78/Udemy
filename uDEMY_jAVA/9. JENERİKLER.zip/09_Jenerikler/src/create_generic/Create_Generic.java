package create_generic;

public class Create_Generic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		A obj = new A(true);
		System.out.println(obj.getType());
	}

}


class A
{
	Object s;
	
	A(Object s){
		this.s = s;
	}
	
	String getType() {
		return s.getClass().getName();
	}
}

class B
{
	Object o1,o2;
	
	B(Object o1,Object o2)
	{
		this.o1=o1;
		this.o2=o2;
	}
	
	void result()
	{
		//System.out.println(o1+o2);   //ERROR
	}
}

