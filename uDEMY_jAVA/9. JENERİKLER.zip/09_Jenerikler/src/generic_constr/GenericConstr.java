package generic_constr;

public class GenericConstr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyClass obj1 = new MyClass(3);
		obj1.show();
		
		
		MyClass obj2 = new MyClass(3.6);
		obj2.show();
		
	}

}

class MyClass
{
	private Object q;
	
	<T extends Number>MyClass (T i){
		q=i;
	}
	
	void show() {
		System.out.println(q+" -> "+ q.getClass().getName());
	}
}


