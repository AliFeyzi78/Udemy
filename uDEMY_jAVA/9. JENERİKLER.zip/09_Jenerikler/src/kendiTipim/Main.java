package kendiTipim;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
		Personel p1 = new Personel();
		p1.isim="Ahmet";
		p1.yas=20;
		
		Personel p2 = new Personel();
		p2.isim="Mehmet";
		p2.yas=30;
		
//		ArrayList<String> isimler = new ArrayList<String>();
//		isimler.add(p1.isim);
//		isimler.add(p2.isim);
//		
//		System.out.println(isimler);
//		
//		ArrayList<Integer> yaslar = new ArrayList<Integer>();
//		yaslar.add(p1.yas);
//		yaslar.add(p2.yas);
		
		ArrayList<Personel> personeller = new ArrayList<Personel>();
		personeller.add(p1);
		personeller.add(p2);
		
		for (Personel p:personeller) {
			System.out.println(p.isim);
			System.out.println(p.yas);
		}
		
		
		Personel<Integer> p3 = new Personel<Integer>();
		p3.isim="Furkan";
		p3.maas = 5000;
		
		Personel<Double> p4 = new Personel<Double>();
		p4.isim = "Serkan";
		p4.maas = 8000.50;
		
		ArrayList<Personel<Integer>> personelListe = new ArrayList<Personel<Integer>>();
		personelListe.add(p3);
		
		
	}

}
