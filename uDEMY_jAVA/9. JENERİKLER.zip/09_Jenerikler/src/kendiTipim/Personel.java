package kendiTipim;

public class Personel<T> {
	public String isim;
	public int yas;
	public T maas;

}
