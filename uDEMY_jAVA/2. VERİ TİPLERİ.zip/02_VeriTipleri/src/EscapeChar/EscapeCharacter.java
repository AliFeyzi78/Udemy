package EscapeChar;

public class EscapeCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/**
		 * \n or \r new line
		 * \t tab space
		 * \ special character
		 */
		
		System.out.println("Welcome to the \"Java\" course");
		

		
	}

}
