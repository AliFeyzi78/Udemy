package TypeCasting;

public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/**
		 * 
		 * type conversions
		 * 
		 * Float to Integer
		 * Integer to Float
		 * String to Integer
		 * Integer to String
		 */
		
		//Float to Integer
		
		Float sayi1 = 13.4f;
		Integer intSayi1 = Math.round(sayi1); //sayi1.intValue();
		System.out.println(intSayi1);
		
		//Integer to Float
		
		Integer intSayi2 = 15;
		Float sayi2 = intSayi2.floatValue();
		System.out.println(sayi2);
		
		//String to Integer
		
		String yas = "20";
		Integer intSayi3 = Integer.valueOf(yas);
		System.out.println(intSayi3);
		
		//Integer to String
		
		Integer intSayi4 = 40;
		String str = intSayi4.toString();
		System.out.println(str);
		
		
		
		
	}

}
