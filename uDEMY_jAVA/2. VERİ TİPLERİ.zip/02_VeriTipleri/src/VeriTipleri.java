
public class VeriTipleri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * String
		 * Char
		 * Byte
		 * Integer
		 * Short
		 * Long
		 * Float
		 * Double
		 * Boolean
		 */
		
		
		String isim = "Özgen";
		System.out.println(isim);
		
		Character karakter = 'a';
		Byte sayi1 = 10;
		System.out.println(sayi1);
		Integer sayi2= 3000;
		System.out.println(sayi2);
		System.out.println(Integer.MIN_VALUE);
		
		Float sayi3 = 13.3f;
		Float sayi5 = (float)13.3;
		Double sayi4 = 12.2d;
		
		Boolean askerlikDurumu = true;
		System.out.println(askerlikDurumu);
		
		
	}

}
