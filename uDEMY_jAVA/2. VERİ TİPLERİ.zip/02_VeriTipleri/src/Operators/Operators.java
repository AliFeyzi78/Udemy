package Operators;

public class Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Integer x;
		Integer s1, s2;
		
		s1=5;
		s2=7;
		x= s2 % s1;
		
		System.out.println(x);
		
		Boolean y;
		y=s1!=s2;
		System.out.println(y);
		
		//And
		//Or
		
		Integer a1,a2,a3,a4;
		a1=7;
		a2=4;
		a3=3;
		a4=5;
		
		Boolean as;
		as = a1==a3 || a2==a4;
		System.out.println(as);

	}

}
