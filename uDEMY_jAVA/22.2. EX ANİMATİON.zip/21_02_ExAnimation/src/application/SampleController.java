package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class SampleController implements Initializable {

	@FXML
    private ImageView image1;

    @FXML
    private Button btn1;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		RotateTransition rt = new RotateTransition(Duration.millis(2000), btn1);
		rt.setByAngle(360);
		rt.play();
		
		btn1.setStyle("-fx-background-color: linear-gradient(#ff5400, #be1d00);\n" + 
				"    -fx-background-radius: 30;\n" + 
				"    -fx-background-insets: 0;\n" + 
				"    -fx-text-fill: white;");
		
		btn1.setScaleX(0.5f);
		btn1.setScaleY(0.5f);
		
		ScaleTransition st = new ScaleTransition(Duration.millis(2000), btn1);
		st.setByX(1.0f);
		st.setByY(1.0f);
		st.play();
		
		TranslateTransition tt = new TranslateTransition(Duration.millis(2000), btn1);
		tt.setToX(+150);
		tt.setToY(+100);
		tt.play();
		
		
		tt.setOnFinished((e)->{
			FadeTransition fd = new FadeTransition(Duration.millis(1500), image1);
			fd.setFromValue(1.0f);
			fd.setToValue(0.0f);
			fd.play();
		});
		
	}
	
}
