package application;



import javafx.animation.FadeTransition;
import javafx.animation.FillTransition;
import javafx.animation.RotateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class SampleController {

    @FXML
    private Button btn1;
    @FXML
    private Button btn2;
    

    @FXML
    void btn1_click(ActionEvent event) {

    		RotateTransition rt = new RotateTransition();
    		rt.setDuration(Duration.millis(1500));
    		rt.setNode(btn1);
    		rt.setByAngle(300);
    		rt.setCycleCount(5); // default 1
    		rt.setAutoReverse(true); // default false
    		
    		rt.play();
    	
    		
    }
    
    @FXML
    void btn2_click(ActionEvent event) {
    		
    		FadeTransition ft = new FadeTransition(Duration.millis(1000), btn2);
    		ft.setFromValue(1.0);
    		ft.setToValue(0);
    		ft.setCycleCount(6);
    		ft.setAutoReverse(true);
    		ft.play();
    	
    	
    }
	
}
