package application;
	

import java.util.Timer;
import java.util.TimerTask;

import javafx.animation.FadeTransition;
import javafx.animation.FillTransition;
import javafx.animation.PathTransition;
import javafx.animation.PathTransition.OrientationType;
import javafx.animation.PauseTransition;
import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.StrokeTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.fxml.FXMLLoader;


public class Main extends Application {
	BorderPane root;
	static int i=0;
	@Override
	public void start(Stage primaryStage) {
		try {
			root = (BorderPane)FXMLLoader.load(getClass().getResource("Sample.fxml"));
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			
//			Rectangle kare = new Rectangle(100, 100, 100, 100);
//			kare.setArcHeight(15);
//			kare.setArcWidth(15);
//			kare.setFill(Color.RED);
//			root.getChildren().add(kare);
//			
////			FillTransition fillt = new FillTransition(Duration.millis(500), kare, Color.RED, Color.BLACK);
////			fillt.setCycleCount(6);
////			fillt.setAutoReverse(true);
////			fillt.play();
//			
//			
//			ScaleTransition st = new ScaleTransition(Duration.millis(1000), kare);
//			st.setByX(0.5f);
//			st.setByY(0.5f);
//			st.setCycleCount(4);
//			st.setAutoReverse(true);
//			st.play();
//			
//			
//			Timer timer = new Timer();
//			TimerTask task = new TimerTask() {
//				
//				@Override
//				public void run() {
//					System.out.println(kare.getScaleX());
//					
//					if (i>200)
//						timer.cancel();
//						
//					i++;
//				}
//			};
//			timer.schedule(task, 0,10);
			
			
//			Rectangle kare = new Rectangle(100, 100, 100, 100);
//			kare.setStrokeWidth(10);
//			root.getChildren().add(kare);
//			
//			StrokeTransition st = new StrokeTransition(Duration.millis(4000),kare,Color.RED,Color.AQUA);
//			st.setCycleCount(4);
//			st.setAutoReverse(true);
//			st.play();
//			
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	public static void main(String[] args) {
		launch(args);
		
		
	}
}
