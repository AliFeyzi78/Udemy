package superUsage1;

public class SuperUsage_1 {
	
	//super

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Operation1 op1 = new Operation1(2,3);
		System.out.println(op1.sonuc());
		
		
		Operation2 op2=  new Operation2(2,3,4);
		System.out.println(op2.sonuc());

	}

}


class Operation1
{
	int edge1,edge2;
	
	Operation1(int e1, int e2){
		edge1 = e1;
		edge2 = e2;
	}
	
	Operation1(){
		edge1 = 1;
		edge2 = 1;
	}
	
	int sonuc() {
		return edge1*edge2;
	}
	
}


class Operation2 extends Operation1
{
	int edge3;
	
	Operation2 (int e1,int e2, int e3){
		super(e1,e2);
		edge3 = e3;
	}
	
	int sonuc() {
		return edge1*edge2*edge3;
	}
}
