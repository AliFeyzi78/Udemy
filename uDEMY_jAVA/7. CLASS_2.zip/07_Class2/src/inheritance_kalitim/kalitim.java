package inheritance_kalitim;

public class kalitim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		//inheritance
		
		Father father = new Father();
		father.printFather();
		
		Child1 child1 = new Child1();
		child1.printChild();
		child1.printFather();
		father.printFather();
		
		Child2 child2 = new Child2();
		child2.printChild2();
		
		Grandson grandson = new Grandson();
		grandson.printGrandson();
		
		
	}

}


class Father
{
	public String prop1;
	
	public void printFather()
	{
		System.out.println("Father class");
	}
}

class Child1 extends Father
{
	public void printChild()
	{
		System.out.println("Child class");
	}
	
	
	public void printFather()
	{
		System.out.println("Father in child class");
	}
}

class Child2 extends Father
{
	public void printChild2()
	{
		System.out.println("Child2 class");
	}
}


class Grandson extends Child1
{
	
	
	public void printGrandson() {
		System.out.println("Grandson class");
	}
}


