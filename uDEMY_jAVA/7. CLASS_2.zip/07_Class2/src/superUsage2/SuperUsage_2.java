package superUsage2;

public class SuperUsage_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Class2 eClass2 = new Class2();
		eClass2.show();
		

	}

}

class Class1{
	int a;
}

class Class2 extends Class1{
	int a;
	
	void show() {
		
		a=15;
		super.a = 38;
		
		System.out.println(a);
		System.out.println(super.a);
	}
}