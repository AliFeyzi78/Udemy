package externalClass;

public class A {
	
	int a,b;
	public int sSum;
	
	public A(int x, int y)
	{
		a=x;
		b=y;
		
		sSum = a+b;
	}
	
	public void show()
	{
		System.out.println(sSum);
	}

}
