
package externalClass;



public class ExtClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a = new A(18,8);
		a.show();

	
		
	}

}
