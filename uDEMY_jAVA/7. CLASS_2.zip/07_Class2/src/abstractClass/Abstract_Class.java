package abstractClass;

public class Abstract_Class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Toyota toyota1 = new Toyota();
		toyota1.color = "red";
		toyota1.horsePower = 100;
		System.out.println("Toyota -> "+toyota1.maxSpeed());
		
		Mercedes mercedes1 = new Mercedes();
		mercedes1.color = "black";
		mercedes1.horsePower=120;
		System.out.println("Mercedes -> "+mercedes1.maxSpeed());
		
		//instanceof
		
		if (mercedes1 instanceof Mercedes)
		{
			System.out.println("Bu nesne Mercesdes sınıfına ait.");
		}
	
	}

}


abstract class Cars
{
	String color;
	int Model, horsePower;
	
	abstract int maxSpeed();
	
	
	
}

class Toyota extends Cars
{
	int maxSpeed() {
		return 2*horsePower;
	}
	
}

class Mercedes extends Cars
{
	int maxSpeed() {
		return 3*horsePower;
	}
}









