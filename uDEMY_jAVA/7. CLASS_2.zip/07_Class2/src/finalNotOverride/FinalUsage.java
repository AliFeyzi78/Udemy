package finalNotOverride;

class FinalUsage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//final

	}

}


//		//NOT EXTENDS
//final class A{
//	
//	
//			//NOT OVERRIDE
//	final void show()
//	{
//		System.out.println("A class");
//	}
//}
//
//class B extends A
//{
//	void show()
//	{
//		System.out.println("B class");
//	}
//}