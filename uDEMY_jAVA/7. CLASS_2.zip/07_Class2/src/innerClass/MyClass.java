package innerClass;

public class MyClass {
	
	String text1, text2;
	
	MyClass(String a, String b)
	{
		text1 = a;
		text2 = b;
	}
	
	void abc()
	{
		System.out.println("abc");
	}
	
	public class Class1
	{
		
		String text3;
		
		Class1(String c)
		{
			text3 = c;
		}
		
		void show()
		{
			System.out.println(text1 + " " + text2 + " - " + text3);
		}
	}

}
