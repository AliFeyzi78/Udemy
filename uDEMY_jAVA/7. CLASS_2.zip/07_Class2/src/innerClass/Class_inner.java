package innerClass;

public class Class_inner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Nested Class
		//Inner Class
		// tr-> iç içe sınıflar
		
		MyClass.Class1 obj1 = new MyClass("Özgen", "İMRAĞ").new Class1("Erzurum");
		obj1.show();
		
		MyClass obj2 = new MyClass("aaaa","bbb");
		obj2.abc();

	}

}
