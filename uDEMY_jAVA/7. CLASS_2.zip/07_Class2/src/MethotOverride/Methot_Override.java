package MethotOverride;

public class Methot_Override {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//OVERRIDE
		
		A a= new A(8,5);
		a.show();
		
		B b= new B(8,5);
		b.show();

	}

}


class A
{
	int a,b;
	A(int x, int y)
	{
		a=x;
		b=y;
	}
	
	void show() {
		System.out.println(a+b);
	}
}


class B extends A
{
	B(int x, int y)
	{
		super(x,y);
	}
	
	void show() {
		System.out.println(a-b);
	}
}

