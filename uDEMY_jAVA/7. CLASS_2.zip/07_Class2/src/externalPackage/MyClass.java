package externalPackage;

import externalClass.A;

public class MyClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		A a = new A(3,18);
		a.show();
		
	}

}
