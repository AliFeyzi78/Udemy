package sample1;

public class Sample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Math1.Plus1 m1 = new Math1(9, 3).new Plus1();
		m1.result();
		
		Math1.Minus1 m2 = new Math1(9,3).new Minus1();
		m2.result();
		
		Math1.DividedBy1 m3 = new Math1(9,3).new DividedBy1();
		m3.result();
		
		Math1.Multiply1 m4 = new Math1(9,3).new Multiply1();
		m4.result();
		
		
	}

}
