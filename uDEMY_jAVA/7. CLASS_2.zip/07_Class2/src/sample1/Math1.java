package sample1;

public class Math1 {
	
	int a,b;
	
	Math1(int x, int y)
	{
		a=x;
		b=y;
	}
	
	public class Plus1 // --> tr - toplama işlemi
	{
		void result()
		{
			System.out.println(a+b);
		}
	}
	
	public class Minus1 // --> tr - çıkarma işlemi
	{
		void result()
		{
			System.out.println(a-b);
		}
	}
	
	
	public class DividedBy1 // --> tr - Bölme işlemi
	{
		void result()
		{
			System.out.println(a/b);
		}
	}
	
	public class Multiply1 // --> tr - Çarpma işlemi
	{
		void result()
		{
			System.out.println(a*b);
		}
	}

}
