package whileDongusu;

public class while_dongusu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//While 
		
		Integer x=11;
//		while (x<10) {
//			System.out.println("Özgen İMRAĞ");
//			x++;
//		}
		
		//do While
		
		do {
			System.out.println("Özgen İMRAĞ");
			x++;
			
		} while (x<10);

	}

}
