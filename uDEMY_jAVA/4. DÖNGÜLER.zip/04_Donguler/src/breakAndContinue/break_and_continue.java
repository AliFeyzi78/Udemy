package breakAndContinue;

public class break_and_continue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//continue
		//break 
		
		for (int i=0;i<10;i++)
		{
			
			if (i==4) break;
			System.out.println(i);
			
			
			
		}
		
		
			
	}

}
