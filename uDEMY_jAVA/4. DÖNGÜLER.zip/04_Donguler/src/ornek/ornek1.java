package ornek;

public class ornek1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Faktoriyel
		
//		Integer sayi = 5;
//		Integer sonuc = 1;
//		
//		for (int i=1;i<=sayi;i++)
//		{
//			sonuc = sonuc*i;
//			
//		}
//		
//		System.out.println(sayi+" sayısının faktoriyeli = "+ sonuc);
		

		
		//ASAL SAYI KONTROLÜ
		
		//2, 3, 5, 7, 11, 13, 17, 19,  23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89 ve 97
		
		Integer sayi = 17;
		Boolean sonuc = true;
		
		for (int i=2;i<sayi;i++)
		{
			if (sayi % i == 0)
			{
				sonuc=false;
				break;
			}
		}
		
		if (sonuc) System.out.println("sayı asal");
		else System.out.println("sayı asal değil");
		
		
		
		
	
	}
	
	

}
