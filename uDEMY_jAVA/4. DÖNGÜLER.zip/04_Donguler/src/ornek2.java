
public class ornek2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		faktoriyel(4);
		faktoriyel(6);
		
	}
	
	public static void faktoriyel(int a)
	{
		Integer sonuc = 1;
		for (int i=1;i<=a;i++)
		{
			sonuc = sonuc*i;
		}
		System.out.println(a+" sayısının faktoriyeli = "+ sonuc);
	}

}



