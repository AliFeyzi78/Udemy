package forDongusu;

public class donguFor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	
//		System.out.println("1 - Özgen İMRAĞ");
//		System.out.println("2 - Özgen İMRAĞ");
//		System.out.println("3 - Özgen İMRAĞ");
//		System.out.println("4 - Özgen İMRAĞ");
//		System.out.println("5 - Özgen İMRAĞ");
//		
		
		//for
		
		for (int i=1;i<=10;i++)
		{
			System.out.println(i+" - Özgen İMRAĞ");
		}
		
		
		
	}

}
