package animatePack2;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.event.ActionEvent;

public class AnimationApp2 {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AnimationApp2 window = new AnimationApp2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AnimationApp2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 665, 509);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btn1 = new JButton("btn1");
		JButton btnBaslat = new JButton("Baslat");
		btnBaslat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Timer timer = new Timer();
				TimerTask task = new TimerTask() {
					
					@Override
					public void run() {
						btn1.setLocation(btn1.getX()+4, btn1.getY());
						if (btn1.getX()>150)
							timer.cancel();
						
					}
				};
				timer.schedule(task,0, 30);
				
			}
		});
		btnBaslat.setBounds(31, 32, 117, 29);
		frame.getContentPane().add(btnBaslat);
		
		
		btn1.setBounds(31, 79, 49, 45);
		frame.getContentPane().add(btn1);
	}

}
