package application;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.animation.ScaleTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class SampleController implements Initializable{
	
	@FXML
    private Button btn1;
	@FXML
    private ImageView imgTop;
	@FXML
    private Rectangle sagPanel;
	@FXML
    private Rectangle t1;

    @FXML
    private Rectangle t2;

    @FXML
    private Rectangle t3;

    @FXML
    private Rectangle t4;

    @FXML
    private Rectangle t5;

    @FXML
    private Rectangle t6;

    @FXML
    private Rectangle t7;

    @FXML
    private Rectangle t8;

    @FXML
    private Rectangle t9;

    @FXML
    private Rectangle t10;

    @FXML
    private Rectangle t11;

    @FXML
    private Rectangle t12;

    @FXML
    private Rectangle t13;

    @FXML
    private Rectangle t14;
    
    @FXML
    private Label lblTebrik;

    @FXML
    private Label lblBitti;
    @FXML
    private ImageView imgBy;
    
	
	Timer timer;
	boolean yatay=true,dikey=false,o1=false;
	
	//yukarı hareket true
	//aşağı hareket false
	//sağa hareket true
	//sola hareket false
	
	List<Rectangle> rectList, ustSira, altSira;

	
	public void sagaHareket() {
		btn1.setLayoutX(btn1.getLayoutX()+10);
	}
	
	public void solaHareket() {
		btn1.setLayoutX(btn1.getLayoutX()-10);
	}

	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	
		Ozellik o = new Ozellik();
		
		rectList = new ArrayList<Rectangle>();
		rectList.add(t1);
		rectList.add(t2);
		rectList.add(t3);
		rectList.add(t4);
		rectList.add(t5);
		rectList.add(t6);
		rectList.add(t7);
		rectList.add(t8);
		rectList.add(t9);
		rectList.add(t10);
		rectList.add(t11);
		rectList.add(t12);
		rectList.add(t13);
		rectList.add(t14);
		
		ustSira = new ArrayList<Rectangle>();
		ustSira.add(t8);
		ustSira.add(t9);
		ustSira.add(t10);
		ustSira.add(t11);
		ustSira.add(t12);
		ustSira.add(t13);
		ustSira.add(t14);
		altSira = new ArrayList<Rectangle>();
		altSira.add(t1);
		altSira.add(t2);
		altSira.add(t3);
		altSira.add(t4);
		altSira.add(t5);
		altSira.add(t6);
		altSira.add(t7);
		
		
		
				timer = new Timer();
				TimerTask task = new TimerTask() {
					@Override
					public void run() {
						
						if (o1) {
							imgBy.setVisible(true);
							imgBy.setLayoutY(imgBy.getLayoutY()+0.5);
							if (imgBy.getLayoutY()+imgBy.getFitHeight()>=btn1.getLayoutY() && imgBy.getLayoutY() <= btn1.getLayoutY()+btn1.getHeight()-2) {
								o1=false;
//								btn1.setPrefWidth(btn1.getPrefWidth()+25);
								imgBy.setVisible(false);
								
								ScaleTransition st = new ScaleTransition(Duration.millis(1000), btn1);
								st.setByX(0.5f);
								st.play();
							}
						}
						
						
						if (o.getKazandi()) {
							timer.cancel();
							System.out.println("KAZANDIN");
							lblTebrik.setVisible(true);
						}
						
						//KAYBETME
						if (!dikey) {
							if (imgTop.getLayoutY()+imgTop.getFitHeight()>=400) {
								timer.cancel();
								lblBitti.setVisible(true);
								System.out.println(o.getPuan());
							}
						}
						
						
						if (!dikey) {
							imgTop.setLayoutY(imgTop.getLayoutY()+1);
						}else {
							imgTop.setLayoutY(imgTop.getLayoutY()-1);
						}
						
						if(yatay) {
							imgTop.setLayoutX(imgTop.getLayoutX()+1);
						}else {
							imgTop.setLayoutX(imgTop.getLayoutX()-1);
						}
						
						if(imgTop.getLayoutY()+imgTop.getFitHeight()>=btn1.getLayoutY() && imgTop.getLayoutY()+imgTop.getFitHeight()<=btn1.getLayoutY()+2) {
							if (imgTop.getLayoutX()+(imgTop.getFitWidth()/2)>=btn1.getLayoutX() && imgTop.getLayoutX()+(imgTop.getFitWidth()/2)<=btn1.getLayoutX()+btn1.getWidth()) {
								dikey=!dikey;
							}
						}
						
						if (imgTop.getLayoutX()+imgTop.getFitWidth()>=sagPanel.getLayoutX()) {
							yatay=!yatay;
						}
						
						if (imgTop.getLayoutY()<=0) {
							dikey=!dikey;
						}
						
						if (imgTop.getLayoutX()<=0) {
							yatay=!yatay;
						}
						
						
						
						if (dikey) {
							
							//---------------ALT SIRA
							
							if (imgTop.getLayoutY()<=78+t1.getHeight() && imgTop.getLayoutY()>=78+t1.getHeight()-2) {
								for (Rectangle r:altSira) {
									if (imgTop.getLayoutX()+(imgTop.getFitWidth()/2)>=r.getLayoutX() && imgTop.getLayoutX()+(imgTop.getFitWidth()/2)<=r.getLayoutX()+r.getWidth()) {
										System.out.println(r.getId());
										r.setVisible(false);
										r.setLayoutY(-100);
										r.setLayoutX(-100);
										dikey=!dikey;
										o.paunEkle();
										if(r.getId().equals("t3")) {
											o1=true;
										}
										return;
									}
								}
							}
							
							//---------------ÜST SIRA
							
							
							if (imgTop.getLayoutY()<=56+t8.getHeight() && imgTop.getLayoutY()>=56+t8.getHeight()-2) {
								for (Rectangle r:ustSira) {
									if (imgTop.getLayoutX()+(imgTop.getFitWidth()/2)>=r.getLayoutX() && imgTop.getLayoutX()+(imgTop.getFitWidth()/2)<=r.getLayoutX()+r.getWidth()) {
										System.out.println(r.getId());
										r.setVisible(false);
										r.setLayoutY(-100);
										r.setLayoutX(-100);
										dikey=!dikey;
										o.paunEkle();
										if(r.getId().equals("t3")) {
											o1=true;
										}
										return;
									}
								}
							}
						}
						
						
						
						if (!yatay) {
							//üst sıra
							if (imgTop.getLayoutY()+(imgTop.getFitHeight()/2) >= 56 && imgTop.getLayoutY()+(imgTop.getFitHeight()/2) <= 56+t8.getHeight()) {
								for (Rectangle r:ustSira) {
									if (imgTop.getLayoutX() <= r.getLayoutX()+r.getWidth()+1 && imgTop.getLayoutX() >= r.getLayoutX()+r.getWidth()-1) {
										System.out.println(r.getId());
										r.setVisible(false);
										r.setLayoutY(-100);
										r.setLayoutX(-100);
										yatay=!yatay;
										o.paunEkle();
										if(r.getId().equals("t3")) {
											o1=true;
										}
										return;
									}
								}
							}
							
							//alt sıra
							if (imgTop.getLayoutY()+(imgTop.getFitHeight()/2) >= 78 && imgTop.getLayoutY()+(imgTop.getFitHeight()/2) <= 78+t8.getHeight()) {
								for (Rectangle r:altSira) {
									if (imgTop.getLayoutX() <= r.getLayoutX()+r.getWidth()+1 && imgTop.getLayoutX() >= r.getLayoutX()+r.getWidth()-1) {
										System.out.println(r.getId());
										r.setVisible(false);
										r.setLayoutY(-100);
										r.setLayoutX(-100);
										yatay=!yatay;
										o.paunEkle();
										if(r.getId().equals("t3")) {
											o1=true;
										}
										return;
									}
								}
							}
						}
						
						if (!dikey) {
							
							//üst sıra
							if (imgTop.getLayoutY()+imgTop.getFitHeight() >= 56 && imgTop.getLayoutY()+imgTop.getFitHeight() <= 56 + 2) {
								for (Rectangle r: ustSira) {
									if (imgTop.getLayoutX() + (imgTop.getFitWidth()/2) >= r.getLayoutX()+(imgTop.getFitWidth()/2) && imgTop.getLayoutX() <= r.getLayoutX()+r.getWidth()) {
										System.out.println(r.getId());
										r.setVisible(false);
										r.setLayoutY(-100);
										r.setLayoutX(-100);
										dikey=!dikey;
										o.paunEkle();
										if(r.getId().equals("t3")) {
											o1=true;
										}
										return;
									}
								}
							}
							//alt sıra
							if (imgTop.getLayoutY()+imgTop.getFitHeight() >= 78 && imgTop.getLayoutY()+imgTop.getFitHeight() <= 78 + 2) {
								for (Rectangle r: altSira) {
									if (imgTop.getLayoutX() + (imgTop.getFitWidth()/2) >= r.getLayoutX()+(imgTop.getFitWidth()/2) && imgTop.getLayoutX() <= r.getLayoutX()+r.getWidth()) {
										System.out.println(r.getId());
										r.setVisible(false);
										r.setLayoutY(-100);
										r.setLayoutX(-100);
										dikey=!dikey;
										o.paunEkle();
										if(r.getId().equals("t3")) {
											o1=true;
										}
										return;
									}
								}
							}
							
						}
						
						if (yatay) {
							//üst sıra
							if(imgTop.getLayoutY()+imgTop.getFitHeight()/2 >= 56 && imgTop.getLayoutY()+imgTop.getFitHeight()/2<=56+t8.getHeight()) {
								for (Rectangle r:ustSira) {
									if (imgTop.getLayoutX()+imgTop.getFitWidth()>=r.getLayoutX() && imgTop.getLayoutX()+imgTop.getFitWidth()<=r.getLayoutX()+2) {
										System.out.println(r.getId());
										r.setVisible(false);
										r.setLayoutY(-100);
										r.setLayoutX(-100);
										yatay=!yatay;
										o.paunEkle();
										if(r.getId().equals("t3")) {
											o1=true;
										}
										return;
									}
								}
							}
							//alt sıra
							if(imgTop.getLayoutY()+imgTop.getFitHeight()/2 >= 78 && imgTop.getLayoutY()+imgTop.getFitHeight()<=78+t8.getHeight()) {
								for (Rectangle r:altSira) {
									if (imgTop.getLayoutX()+imgTop.getFitWidth()>=r.getLayoutX()-2 && imgTop.getLayoutX()+imgTop.getFitWidth()<=r.getLayoutX()+2) {
										System.out.println(r.getId());
										r.setVisible(false);
										r.setLayoutY(-100);
										r.setLayoutX(-100);
										yatay=!yatay;
										o.paunEkle();
										if(r.getId().equals("t3")) {
											o1=true;
										}
										return;
									}
								}
							}
						}
						
						
						
						
						
						
						
						
						
					}
				};
				timer.schedule(task, 0,10);
				
			
		
		
		
		btn1.setOnKeyPressed(event->{
			switch (event.getCode()) {
			case RIGHT:
				sagaHareket();
				break;
			case LEFT:
				solaHareket();
				break;
			default:
				break;
			}
		});
	}
	
}
