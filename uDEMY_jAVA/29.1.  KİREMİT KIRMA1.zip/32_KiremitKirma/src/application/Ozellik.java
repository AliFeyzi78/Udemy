package application;

public class Ozellik {

	private int puan=0;
	private int kkiremit=0; //kırılan kiremit sayısı
	
	private boolean kazandi=false, kaybetti=false;
	
	public void paunEkle() {
		kkiremit++;
		puan+=10;
		System.out.println(puan);
		if (kkiremit==14) {
			kazandi=true;
		}
	}

	public String getPuan() {
		return String.valueOf(puan);
	}

	public int getKkiremit() {
		return kkiremit;
	}
	
	
	public boolean getKazandi() {
		return kazandi;
	}
	
}
