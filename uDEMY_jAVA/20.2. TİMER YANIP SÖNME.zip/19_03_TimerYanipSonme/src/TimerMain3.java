import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.event.ActionEvent;

public class TimerMain3 {

	private JFrame frame;
	private static boolean durum=true;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TimerMain3 window = new TimerMain3();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public TimerMain3() {
		initialize();
	}


	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Timer timer=new Timer();
				TimerTask timerTask=new TimerTask() {
					
					@Override
					public void run() {
						if(durum) {
							btnNewButton.setVisible(false);
							durum=false;
						}else {
							btnNewButton.setVisible(true);
							durum=true;
						}
						
						
					}
				};
				
				timer.schedule(timerTask, 1000,1000);
				
			}
		});
		btnNewButton.setBounds(147, 109, 138, 64);
		frame.getContentPane().add(btnNewButton);
	}

}
