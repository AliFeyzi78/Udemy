package collect4Set;

import java.util.*;

public class Collect4 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//Set interface
		
		Set<String> list1 = new HashSet<>();
		list1.add("Özgen");
		list1.add("Arif");
		list1.add("Erkut");
		list1.add("Faruk");
		list1.add("Arif");
		
		
		
		
		for (String s : list1) {
			System.out.println(s);
		}
		
		
		System.out.println("---");
		
		
		Set<String> list2 = new TreeSet<>();
		list2.add("Özgen");
		list2.add("Arif");
		list2.add("Erkut");
		list2.add("Faruk");
		list2.add("Arif");
		
		for (String str : list2) {
			System.out.println(str);
		}
		
		
	}

}

