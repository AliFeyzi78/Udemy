package collect1;

import java.util.ArrayList;

public class Collect1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//COLLECTIONS	
	
		ArrayList<String> myCollect = new ArrayList<String>();
		myCollect.add("Özgen");
		myCollect.add("Erkut");
		myCollect.add("İbrahim");
		
		//list elements
		
		System.out.println(myCollect.get(2));
		
		for (int i=0; i<myCollect.size(); i++) {
			System.out.println(myCollect.get(i));
		}
		
		for (String obj : myCollect) {
			System.out.println(obj);
		}
		
		//-------------
		
		//System.out.println(myCollect);
	}

}
