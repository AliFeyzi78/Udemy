package immutableList;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DegismezListeler {

	public static void main(String[] args) {
		//Immutable List
		
//		Set<String> list1 = new HashSet<>();
//		list1.add("Özgen");
//		list1.add("Faruk");
//		list1.add("Oğuzhan");
//		System.out.println(list1);
//		list1 = Collections.unmodifiableSet(list1);
//		list1.add("Sefa");
//		System.out.println(list1);
		
		
		//Java9 sonrası

//		Set<Integer> list2 = Set.of(10,20,30,40);
//		System.out.println(list2);
//		list2.add(50);  //error
//		System.out.println(list2);
		
		
		List<String> list3 = List.of("Özgen","Faruk");
		System.out.println(list3);
		list3.add("Oğuzhan");
	}

}
