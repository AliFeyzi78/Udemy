package collect7;

import java.util.*;

public class Collect7Queue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Queue<Integer> list1 = new LinkedList();
		list1.add(10);
		list1.add(20);
		list1.add(30);
		list1.add(40);
		list1.offer(50);
		
		
		System.out.println(list1);
		
		System.out.println(list1.element());
		System.out.println(list1.peek());
		System.out.println(list1);
		
		System.out.println(list1.remove());
		System.out.println(list1.remove());
		System.out.println(list1.poll());
		System.out.println(list1);
		
		System.out.println("------");
		
		Deque<Integer> list2 = new LinkedList();
		list2.add(10);
		list2.add(20);
		list2.add(30);
		list2.add(40);
		list2.addFirst(5);
		list2.addLast(50);
		
		System.out.println(list2);
//		System.out.println(list2.element());
		System.out.println(list2.remove());
		System.out.println(list2.remove());
		System.out.println(list2);
		list2.add(60);
		System.out.println(list2);
		list2.push(70);
		System.out.println(list2);
		System.out.println(list2.getFirst());
		System.out.println(list2.getLast());
		
	}

}
