package collect2;

import java.util.*;

class pc<T>{
	int cpu; // core number
	T ram; 
}

public class Collect2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> myList = new ArrayList<String>();
		
		
		ArrayList<MyType> list1 =  new ArrayList<MyType>();
		
		MyType myType = new MyType();
		myType.id = 1;
		myType.name = "Özgen";
		
		MyType myType2 = new MyType();
		myType2.id = 2;
		myType2.name = "Erkut";
		
		MyType myType3 = new MyType();
		myType3.id = 3;
		myType3.name = "İbrahim";
		
		list1.add(myType);
		list1.add(myType2);
		
		list1.add(1, myType3);
		
		
		
		
		for (MyType mt : list1) {
			System.out.println(mt.id + " "+ mt.name);
		}
		
		
		//----------------------
		
		ArrayList<pc> pcList = new ArrayList<pc>();
		
		pc<String> pc1 = new pc<String>();
		pc1.cpu=8;
		pc1.ram="8GB";
		
		pc<Integer> pc2 = new pc<Integer>();
		pc2.cpu = 6;
		pc2.ram = 16;
		
		pcList.add(pc1);
		pcList.add(pc2);
		
		for(int i=0; i<pcList.size(); i++) {
			System.out.println(pcList.get(i).cpu + " " + pcList.get(i).ram);
		}
		
	}

}









