package collect2;

public class MyType {
	int id;
	String name;

}
