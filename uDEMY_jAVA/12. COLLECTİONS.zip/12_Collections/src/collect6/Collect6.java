package collect6;

import java.util.*;

public class Collect6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<String,Integer> map1 = new LinkedHashMap();
		map1.put("Özgen", 27);
		map1.put("Gökhan", 28);
		map1.put("Arif", 23);
		map1.put("Erkut", 33);
		
		
		
//		map1.entrySet().forEach(System.out::println);
		
		Set set = map1.entrySet(); 
		Iterator i = set.iterator();
		for (int q = 0;q<map1.size();q++)
			System.out.println(i.next());
		
		
		Deque<Integer> dq = new LinkedList();
		dq.add(12);
		dq.add(18);
		dq.add(20);
		dq.addFirst(5);
		dq.addLast(4);
		dq.remove();
		dq.push(14);
		
		
		System.out.println(dq);
		
		System.out.println(dq.poll());
		
		System.out.println(dq);
		
	}

}
