package collect3;

import java.util.ArrayList;
import java.util.Collections;
public class Collect3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> list1 = new ArrayList<String>();
		list1.add("Özgen");
		list1.add("İbrahim");
		list1.add("Erkut");
		
		
		ArrayList<String> list2 = new ArrayList<String>();
		list2.add("Arzu");
		list2.add("Özgen");
		list2.add("Mine");
		
		list1.addAll(list2);
		
		
//		System.out.println(list1.subList(0, 3));  
		
		
		//search
		//indexOf - lastIndexOf
		
		System.out.println(list1.indexOf("Özgen"));
		System.out.println(list1.lastIndexOf("Özgen"));
		
		
		//get
		System.out.println("1->"+list1.get(1));
		
		
		//clear
//		list1.clear();
		
		//clone
		ArrayList b;
		b = (ArrayList) list1.clone();
		System.out.println(b);
		
		
		//sort
		Collections.sort(list1);
		
		
		
//		list1.remove(1); //delete
		
		for (String str : list1)
			System.out.println(str);
	
	}

}
