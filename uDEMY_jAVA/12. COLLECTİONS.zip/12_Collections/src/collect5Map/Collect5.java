package collect5Map;

import java.util.*;

public class Collect5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<String,Integer> map1 = new TreeMap();
		map1.put("Özgen", 27);
		map1.put("Gökhan", 28);
		map1.put("Arif", 23);
		map1.put("Erkut", 33);
//		map1.put("Özgen", 30);
		
		//usage 1
		
		for (Map.Entry<String, Integer> entry : map1.entrySet()) {
			System.out.println(entry);
		}
		
		//usage 2
		
		Set<String> key = map1.keySet();
		for (String str : key)
			System.out.println(str + " " + map1.get(str));
		

		
		
		
	}

}
